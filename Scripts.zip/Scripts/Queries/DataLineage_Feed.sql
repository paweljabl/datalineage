select 'DV_' || NAME AS NAME, NAME AS DISPLAY_NAME, 'Data vault ' || D.OBJECT_TYPE AS DESCRIPTION
, 'Table' AS ENTITY, 'Netezza' AS TECHNOLOGY
from D_TABLE d
where d.ENVIRONMENT = 'PROD'
and d.technical_area = 'Data Vault'
;

SELECT RELATION_TYPE, count(*) FROM D_TABLE_RELATION group by RELATION_TYPE;

select distinct  'DV_' || ta.name as node_a
, 'absorbs' AS RELATION_TYPE
, R.RELATION_LEVEL 
, 'DV_' || tB.name as node_B
from D_TABLE_RELATION r
join d_table ta on r.TABLE_TK_A = ta.TABLE_TK
	and ta.technical_area = 'Data Vault'
	and ta.ENVIRONMENT = 'PROD'
join d_table tb on r.TABLE_TK_b = tb.TABLE_TK
	and tb.technical_area = 'Data Vault'
	and tb.ENVIRONMENT = 'PROD'
;

select distinct  'DV_' || d.name as node_a
, 'belongs to' AS RELATION_TYPE
, 1 AS RELATION_LEVEL 
, 'DV_' || d.subject_area as node_B
from D_TABLE d
where d.ENVIRONMENT = 'PROD'
and d.technical_area = 'Data Vault'
;

select distinct  'DV_' || d.subject_area as node_a
, 'belongs to' AS RELATION_TYPE
, 1 AS RELATION_LEVEL 
, 'PROD_EDW_DATAVAULT' as node_B
from D_TABLE d
where d.ENVIRONMENT = 'PROD'
and d.technical_area = 'Data Vault'
;