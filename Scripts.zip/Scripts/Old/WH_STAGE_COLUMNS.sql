drop table DEV_DWHU_STAGING..POC_WH_STAGE_COLUMNS;
CREATE TABLE DEV_DWHU_STAGING..POC_WH_STAGE_COLUMNS
(
  oo_name varchar(64)
, oo_active varchar(1)
, sc_obj_key integer
, sc_col_key integer
, sc_col_name varchar(64)
, sc_display_name varchar(256)
, sc_data_type varchar(256)
, sc_nulls_flag varchar(1)
, sc_numeric_flag varchar(1)
, sc_additive_flag varchar(1)
, sc_attribute_flag varchar(1)
, sc_format varchar(64)
, sc_src_table varchar(64)
, sc_src_column varchar(64)
, sc_order integer
, sc_key_type varchar(1)
, sc_join_flag varchar(1)
, sc_business_key_ind varchar(1)
, sc_primary_index_ind varchar(1)
, sc_default_value varchar(1024)
, sc_case_flag varchar(1)
, sc_title varchar(64)
, sc_compress_flag varchar(1)
, sc_comments varchar(256)
, sc_col_type varchar(64)
, sc_update_flag varchar(1)
, sc_display_type varchar(64)
, sc_pre_join_source varchar(64)
, sc_ind_1 varchar(1)
)
;

select * from DEV_DWHU_STAGING..POC_WH_STAGE_COLUMNS
where oo_name like '%LISA%'
order by SC_OBJ_KEY, SC_ORDER;