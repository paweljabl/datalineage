DROP TABLE DEV_DWHU_STAGING..POC_WH_LNK_COLUMNS;
CREATE TABLE DEV_DWHU_STAGING..POC_WH_LNK_COLUMNS
(
  oo_name varchar(64)
, oo_active varchar(1)
, nc_obj_key integer
, nc_col_key integer
, nc_col_name varchar(64)
, nc_display_name varchar(256)
, nc_data_type varchar(256)
, nc_nulls_flag varchar(1)
, nc_numeric_flag varchar(1)
, nc_additive_flag varchar(1)
, nc_attribute_flag varchar(1)
, nc_format varchar(64)
, nc_src_table varchar(64)
, nc_src_column varchar(64)
, nc_order integer
, nc_key_type varchar(1)
, nc_join_flag varchar(1)
, nc_business_key_ind varchar(1)
, nc_primary_index_ind varchar(1)
, nc_default_value varchar(1024)
, nc_case_flag varchar(1)
, nc_title varchar(64)
, nc_compress_flag varchar(1)
, nc_comments varchar(256)
, nc_col_type varchar(64)
, nc_update_flag varchar(1)
, nc_display_type varchar(64)
, nc_pre_join_source varchar(64)
, nc_ind_1 varchar(1)
)
;