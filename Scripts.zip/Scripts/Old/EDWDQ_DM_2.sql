--==============================================================
-- DBMS name:      Netezza 7.0 - Volvo
-- Created on:     2018-02-22 13:42:36
--==============================================================


drop table D_BUSINESS_AREA;

drop table D_DATE;

drop table D_JOB;

drop table D_JOB_SCREEN;

drop table D_SCREEN;

drop table D_SCREEN_CATEGORY;

drop table D_TABLE;

drop table F_SCREEN_EVENTS;

drop table F_SCREEN_RUN;

--==============================================================
-- Table: D_BUSINESS_AREA
--==============================================================
create table D_BUSINESS_AREA (
   BUSINESS_AREA_TK     BIGINT                         not null,
   TECHNICAL_AREA       CHARACTER VARYING(50)          null,
   BUSINESS_AREA        CHARACTER VARYING(50)          null,
   constraint PK_D_BUSINESS_AREA primary key (BUSINESS_AREA_TK)
)
distribute on random;

comment on table D_BUSINESS_AREA is
'Dimension breaking down EDW into technical and business areas.';

--==============================================================
-- Table: D_DATE
--==============================================================
create table D_DATE (
   DATE_TK              BIGINT                         not null,
   DATE                 DATE                           null,
   FULL_DATE_UK         CHARACTER(10)                  null,
   FULL_DATE_USA        CHARACTER(10)                  null,
   DAY_OF_MONTH         CHARACTER VARYING(2)           null,
   DAY_SUFFIX           CHARACTER VARYING(4)           null,
   DAY_NAME             CHARACTER VARYING(9)           null,
   DAY_OF_WEEK_USA      CHARACTER(1)                   null,
   DAY_OF_WEEK_UK       CHARACTER(1)                   null,
   DAY_OF_WEEK_IN_MONTH CHARACTER VARYING(2)           null,
   DAY_OF_WEEK_IN_YEAR  CHARACTER VARYING(2)           null,
   DAY_OF_QUARTER       CHARACTER VARYING(3)           null,
   DAY_OF_YEAR          CHARACTER VARYING(3)           null,
   WEEK_OF_MONTH        CHARACTER VARYING(1)           null,
   WEEK_OF_QUARTER      CHARACTER VARYING(2)           null,
   WEEK_OF_YEAR         CHARACTER VARYING(2)           null,
   MONTH                CHARACTER VARYING(2)           null,
   MONTH_NAME           CHARACTER VARYING(9)           null,
   MONTH_OF_QUARTER     CHARACTER VARYING(2)           null,
   QUARTER              CHARACTER(1)                   null,
   QUARTER_NAME         CHARACTER VARYING(9)           null,
   YEAR                 CHARACTER(4)                   null,
   YEAR_NAME            CHARACTER(7)                   null,
   MONTH_YEAR           CHARACTER(10)                  null,
   MMYYYY               CHARACTER(6)                   null,
   FIRST_DAY_OF_MONTH   DATE                           null,
   LAST_DAY_OF_MONTH    DATE                           null,
   FIRST_DAY_OF_QUARTER DATE                           null,
   LAST_DAY_OF_QUARTER  DATE                           null,
   FIRST_DAY_OF_YEAR    DATE                           null,
   LAST_DAY_OF_YEAR     DATE                           null,
   IS_WEEK_DAY          CHARACTER(1)                   null,
   constraint PK_D_DATE primary key (DATE_TK)
)
distribute on hash (DATE_TK);

comment on table D_DATE is
'Generic date dimension';

--==============================================================
-- Table: D_JOB
--==============================================================
create table D_JOB (
   JOB_TK               BIGINT                         not null,
   JOB_NAME             CHARACTER VARYING(50)          not null,
   JOB_DESCRIPTION      CHARACTER VARYING(255)         null,
   NOTIFICATION_EMAIL_NO_ISSUES CHARACTER VARYING(255)         null,
   NOTIFICATION_EMAIL_ISSUES CHARACTER VARYING(255)         null,
   constraint PK_D_JOB primary key (JOB_TK)
)
distribute on random;

comment on table D_JOB is
'Configuration table, storing job specifc parameters, description , meaningful code, notification email etc.
It''s needed to server as for grouping of screens that need to be executed within one job';

--==============================================================
-- Table: D_JOB_SCREEN
--==============================================================
create table D_JOB_SCREEN (
   JOB_SCREEN_TK        BIGINT                         not null,
   JOB_TK               BIGINT                         null,
   SCREEN_TK            BIGINT                         null,
   PROCESSING_ORDER_NB  BIGINT                         null,
   constraint PK_D_JOB_SCREEN primary key (JOB_SCREEN_TK)
)
distribute on random;

comment on table D_JOB_SCREEN is
'Configuration table storing screens that should be performed within one execution of the job.';

--==============================================================
-- Table: D_SCREEN
--==============================================================
create table D_SCREEN (
   SCREEN_TK            BIGINT                         not null,
   SCREEN_CATEGORY_TK   BIGINT                         null,
   BUSINESS_AREA_TK     BIGINT                         null,
   TABLE_TK             BIGINT                         null,
   SCREEN_SPECIFIC_SQL  NATIONAL CHARACTER VARYING(2000) null,
   ACTIVE               CHARACTER(1)                   null,
   COLUMN_NAME          CHARACTER VARYING(255)         null,
   COLUMN_DELETED       CHARACTER(1)                   null,
   constraint PK_D_SCREEN primary key (SCREEN_TK)
)
distribute on hash (SCREEN_TK);

comment on table D_SCREEN is
'Configuration table storing screen definition.';

--==============================================================
-- Table: D_SCREEN_CATEGORY
--==============================================================
create table D_SCREEN_CATEGORY (
   SCREEN_CATEGORY_TK   BIGINT                         not null,
   SCREEN_CATAGORY      CHARACTER VARYING(50)          not null,
   SCREEN_TYPE          CHARACTER VARYING(50)          not null,
   SCREEN_NAME          CHARACTER VARYING(100)         null,
   SCREEN_DEFINITION    NATIONAL CHARACTER VARYING(255) null,
   SCREEN_SQL_TYPE      CHARACTER VARYING(50)          null,
   SCREEN_GENERIC_SQL   NATIONAL CHARACTER VARYING(2000) null,
   constraint PK_D_SCREEN_CATEGORY primary key (SCREEN_CATEGORY_TK)
)
distribute on random;

comment on table D_SCREEN_CATEGORY is
'Configuration table storing screen categories, types and generic definition.';

--==============================================================
-- Table: D_TABLE
--==============================================================
create table D_TABLE (
   TABLE_TK             BIGINT                         not null,
   DATABASE_NAME        CHARACTER VARYING(50)          null,
   ENTITY_TYPE          CHARACTER VARYING(20)          null,
   NAME                 CHARACTER VARYING(255)         null,
   constraint PK_D_TABLE primary key (TABLE_TK)
)
distribute on hash (TABLE_TK);

comment on table D_TABLE is
'Dimension listing EDW tables; There needs to be one ''N/A'' record added for screens not applicable on table / view level.';

--==============================================================
-- Table: F_SCREEN_EVENTS
--==============================================================
create table F_SCREEN_EVENTS (
   SCREEN_RUN_TK        BIGINT                         not null,
   SCREEN_EVENT_NB      BIGINT                         not null,
   SCREEN_RUN_DATE_TK   BIGINT                         null,
   SCREEN_TK            BIGINT                         not null,
   SCREEN_RUN_TIME      TIMESTAMP                      null,
   TABLE_TK             BIGINT                         not null,
   FIELD_NAME           CHARACTER VARYING(255)         not null,
   TABLE_ROWID          BIGINT                         null,
   SCREEN_VIOLATION_CONDITION NATIONAL CHARACTER VARYING(500) null,
   constraint PK_F_SCREEN_EVENTS primary key (SCREEN_RUN_TK, SCREEN_EVENT_NB, SCREEN_TK, TABLE_TK, FIELD_NAME)
)
distribute on random;

comment on table F_SCREEN_EVENTS is
'Each data-quality vialation within a single screen is captured as a row in the event fact table. One screen can return as many records as there a table records for table / column screens. Sometimes one error is reflected by 2, 3 or more records for complex structure or business rule screen, where a single event generates many rows in this error event  fact table. Thus, SCREEN_EVENT_NB helps to group records accountable for one screen event. Most of the time however it will be one record per registered error, for example one record for each NULL record in specific column.';

--==============================================================
-- Table: F_SCREEN_RUN
--==============================================================
create table F_SCREEN_RUN (
   SCREEN_RUN_TK        BIGINT                         not null,
   SCREEN_TK            BIGINT                         null,
   SCREEN_RUN_DATE_TK   BIGINT                         not null,
   SCREEN_RUN_TIME      TIMESTAMP                      null,
   VIOLATED_RECORDS_QT  BIGINT                         null,
   TOTAL_RECORDS_QT     BIGINT                         null,
   constraint PK_F_SCREEN_RUN primary key (SCREEN_RUN_TK)
)
distribute on random;

comment on table F_SCREEN_RUN is
'Each row in this table correspondes to a screen run, giving details such as total number of error records, total number of good records etc.';

alter table D_JOB_SCREEN add constraint FK_JOB_SCREEN_2_JOB foreign key (JOB_TK)
   references D_JOB (JOB_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table D_JOB_SCREEN add constraint FK_JOB_SCREEN_2_SCREEN foreign key (SCREEN_TK)
   references D_SCREEN (SCREEN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table D_SCREEN add constraint FK_SCREEN_2_BUSINESS_AREA foreign key (BUSINESS_AREA_TK)
   references D_BUSINESS_AREA (BUSINESS_AREA_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table D_SCREEN add constraint FK_SCREEN_2_TABLE foreign key (TABLE_TK)
   references D_TABLE (TABLE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table D_SCREEN add constraint FK_SCREEN_CATEGORY_2_SCREEN foreign key (SCREEN_CATEGORY_TK)
   references D_SCREEN_CATEGORY (SCREEN_CATEGORY_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_DATE foreign key (SCREEN_RUN_DATE_TK)
   references D_DATE (DATE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_SCREEN foreign key (SCREEN_TK)
   references D_SCREEN (SCREEN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_SCREEN_RUN foreign key (SCREEN_RUN_TK)
   references F_SCREEN_RUN (SCREEN_RUN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_TABLE foreign key (TABLE_TK)
   references D_TABLE (TABLE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_RUN add constraint FK_SCREEN_RUN_2_DATE foreign key (SCREEN_RUN_DATE_TK)
   references D_DATE (DATE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_RUN add constraint FK_SCREEN_RUN_2_SCREEN foreign key (SCREEN_TK)
   references D_SCREEN (SCREEN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

