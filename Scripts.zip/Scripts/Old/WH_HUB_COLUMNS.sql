drop table DEV_DWHU_STAGING..POC_WH_HUB_COLUMNS;
CREATE TABLE DEV_DWHU_STAGING..POC_WH_HUB_COLUMNS
(
  oo_name varchar(64)
, oo_active varchar(1)
, dc_obj_key integer
, dc_col_key integer
, dc_col_name varchar(64)
, dc_display_name varchar(256)
, dc_data_type varchar(256)
, dc_nulls_flag varchar(1)
, dc_numeric_flag varchar(1)
, dc_additive_flag varchar(1)
, dc_attribute_flag varchar(1)
, dc_format varchar(64)
, dc_src_table varchar(64)
, dc_src_column varchar(64)
, dc_order integer
, dc_key_type varchar(1)
, dc_join_flag varchar(1)
, dc_business_key_ind varchar(1)
, dc_primary_index_ind varchar(1)
, dc_default_value varchar(1024)
, dc_case_flag varchar(1)
, dc_title varchar(64)
, dc_compress_flag varchar(1)
, dc_comments varchar(256)
, dc_col_type varchar(64)
, dc_update_flag varchar(1)
, dc_display_type varchar(64)
, dc_pre_join_source varchar(64)
, dc_ind_1 varchar(1)
)
;