--==============================================================
-- DBMS name:      Netezza 7.0 - Volvo
-- Created on:     2018-02-22 09:56:17
--==============================================================


drop table D_BUSINESS_AREA;

drop table D_DATE;

drop table D_JOB;

drop table D_JOB_SCREEN;

drop table D_SCREEN;

drop table D_SCREEN_CATEGORY;

drop table D_TABLE;

drop table F_SCREEN_EVENTS;

drop table F_SCREEN_RUN;

--==============================================================
-- Table: D_BUSINESS_AREA
--==============================================================
create table D_BUSINESS_AREA (
   BUSINESS_AREA_TK     BIGINT                         not null,
   TECHNICAL_AREA       CHARACTER VARYING(50)          null,
   BUSINESS_AREA        CHARACTER VARYING(50)          null,
   constraint PK_D_BUSINESS_AREA primary key (BUSINESS_AREA_TK)
)
distribute on random;

comment on table D_BUSINESS_AREA is
'Dimension breaking down EDW into technical and business areas.';

comment on column D_BUSINESS_AREA.BUSINESS_AREA_TK is
'Pirmary key - surrogate key
';

comment on column D_BUSINESS_AREA.TECHNICAL_AREA is
'Field defines whether screen is applied within Data Vault, Data Mart, Staging database area';

comment on column D_BUSINESS_AREA.BUSINESS_AREA is
'Field defines Source System, for example VDA, CTDI etc, or Data Mart area for example PARTS, PROPER etc';

--==============================================================
-- Table: D_DATE
--==============================================================
create table D_DATE (
   DATE_TK              BIGINT                         not null,
   DATE                 DATE                           null,
   FULL_DATE_UK         CHARACTER(10)                  null,
   FULL_DATE_USA        CHARACTER(10)                  null,
   DAY_OF_MONTH         CHARACTER VARYING(2)           null,
   DAY_SUFFIX           CHARACTER VARYING(4)           null,
   DAY_NAME             CHARACTER VARYING(9)           null,
   DAY_OF_WEEK_USA      CHARACTER(1)                   null,
   DAY_OF_WEEK_UK       CHARACTER(1)                   null,
   DAY_OF_WEEK_IN_MONTH CHARACTER VARYING(2)           null,
   DAY_OF_WEEK_IN_YEAR  CHARACTER VARYING(2)           null,
   DAY_OF_QUARTER       CHARACTER VARYING(3)           null,
   DAY_OF_YEAR          CHARACTER VARYING(3)           null,
   WEEK_OF_MONTH        CHARACTER VARYING(1)           null,
   WEEK_OF_QUARTER      CHARACTER VARYING(2)           null,
   WEEK_OF_YEAR         CHARACTER VARYING(2)           null,
   MONTH                CHARACTER VARYING(2)           null,
   MONTH_NAME           CHARACTER VARYING(9)           null,
   MONTH_OF_QUARTER     CHARACTER VARYING(2)           null,
   QUARTER              CHARACTER(1)                   null,
   QUARTER_NAME         CHARACTER VARYING(9)           null,
   YEAR                 CHARACTER(4)                   null,
   YEAR_NAME            CHARACTER(7)                   null,
   MONTH_YEAR           CHARACTER(10)                  null,
   MMYYYY               CHARACTER(6)                   null,
   FIRST_DAY_OF_MONTH   DATE                           null,
   LAST_DAY_OF_MONTH    DATE                           null,
   FIRST_DAY_OF_QUARTER DATE                           null,
   LAST_DAY_OF_QUARTER  DATE                           null,
   FIRST_DAY_OF_YEAR    DATE                           null,
   LAST_DAY_OF_YEAR     DATE                           null,
   IS_WEEK_DAY          CHARACTER(1)                   null,
   constraint PK_D_DATE primary key (DATE_TK)
);

comment on table D_DATE is
'Generic date dimension';

comment on column D_DATE.FULL_DATE_UK is
'dd-MM-yyyy format';

comment on column D_DATE.FULL_DATE_USA is
'Date in MM-dd-yyyy format';

comment on column D_DATE.DAY_OF_MONTH is
'Field will hold day number of Month';

comment on column D_DATE.DAY_SUFFIX is
'Apply suffix as 1st, 2nd ,3rd etc';

comment on column D_DATE.DAY_NAME is
'Contains name of the day, Sunday, Monday';

comment on column D_DATE.DAY_OF_WEEK_USA is
'First Day Sunday=1 and Saturday=7';

comment on column D_DATE.DAY_OF_WEEK_UK is
'First Day Monday=1 and Sunday=7';

comment on column D_DATE.DAY_OF_WEEK_IN_MONTH is
'1st Monday or 2nd Monday in Month';

comment on column D_DATE.WEEK_OF_MONTH is
'Week Number of Month ';

comment on column D_DATE.WEEK_OF_QUARTER is
'Week Number of the Quarter';

comment on column D_DATE.WEEK_OF_YEAR is
'Week Number of the Year';

comment on column D_DATE.MONTH is
'Number of the Month 1 to 12';

comment on column D_DATE.MONTH_NAME is
'January, February etc';

comment on column D_DATE.MONTH_OF_QUARTER is
'Month Number belongs to Quarter';

comment on column D_DATE.QUARTER_NAME is
'First,Second..';

comment on column D_DATE.YEAR is
'Year value of Date stored in Row';

comment on column D_DATE.YEAR_NAME is
'CY 2012,CY 2013';

comment on column D_DATE.MONTH_YEAR is
'Jan-2013,Feb-2013';

comment on column D_DATE.IS_WEEK_DAY is
'0=Week End ,1=Week Day';

--==============================================================
-- Table: D_JOB
--==============================================================
create table D_JOB (
   JOB_TK               BIGINT                         not null,
   JOB_NAME             CHARACTER VARYING(50)
                                not null,
   JOB_DESCRIPTION      CHARACTER VARYING(255)
                               null,
   NOTIFICATION_EMAIL_NO_ISSUES CHARACTER VARYING(255)
                                       null,
   NOTIFICATION_EMAIL_ISSUES CHARACTER VARYING(255)
                                    null,
   constraint PK_D_JOB primary key (JOB_TK)
)
distribute on random;

comment on table D_JOB is
'Configuration table, storing job specifc parameters, description , meaningful code, notification email etc.
It''s needed to server as for grouping of screens that need to be executed within one job';

comment on column D_JOB.JOB_TK is
'Pirmary key - surrogate key; 
';

comment on column D_JOB.JOB_NAME is
'Short name that would be meaningful , and would resemble screens executed wihin the job';

comment on column D_JOB.JOB_DESCRIPTION is
'Long description of the job purpose and contents.';

comment on column D_JOB.NOTIFICATION_EMAIL_NO_ISSUES is
'Notification email that would serve to send email regardless whether there were any issues reported';

comment on column D_JOB.NOTIFICATION_EMAIL_ISSUES is
'Notification email that would serve to send email with the result of the job if some screens returns data quality issues.';

--==============================================================
-- Table: D_JOB_SCREEN
--==============================================================
create table D_JOB_SCREEN (
   JOB_SCREEN_TK        BIGINT                         not null,
   JOB_TK               BIGINT                         null,
   SCREEN_TK            BIGINT                         null,
   PROCESSING_ORDER_NB	BIGINT                         null,
   constraint PK_D_JOB_SCREEN primary key (JOB_SCREEN_TK)
)
distribute on random;

comment on table D_JOB_SCREEN is
' Configuration table storing screens that should be performed within one execution of the job.';

comment on column D_JOB_SCREEN.JOB_SCREEN_TK is
'Primary key - surrogate key';

comment on column D_JOB_SCREEN.JOB_TK is
'The key to D_JOB';

comment on column D_JOB_SCREEN.SCREEN_TK is
'The key to D_SCREEN';

comment on column D_JOB_SCREEN.PROCESSING_ORDER_NB is
'It''s a primitive scheduling/dependency device, informing the overall ETL master process of the order 
in which to run the screens. Data-quality screens with the same processing-order number can be run in parallel.';

--==============================================================
-- Table: D_SCREEN
--==============================================================
create table D_SCREEN (
   SCREEN_TK            BIGINT                         not null,
   SCREEN_CATEGORY_TK   BIGINT                         null,
   BUSINESS_AREA_TK     BIGINT                         null,
   TABLE_TK             BIGINT                         null,
   SCREEN_SPECIFIC_SQL  NATIONAL CHARACTER VARYING(2000) null,
   ACTIVE               CHARACTER(1)                   null,
   COLUMN_NAME          CHARACTER VARYING(255)		   null,
   COLUMN_DELETED       CHARACTER(1)                   null,
   SCREEN_LAST_RUN		TIMESTAMP,
   constraint PK_D_SCREEN primary key (SCREEN_TK)
);

comment on table D_SCREEN is
'Configuration table storing screen definition.';

comment on column D_SCREEN.SCREEN_TK is
'Pirmary key - surrogate key';

comment on column D_SCREEN.SCREEN_CATEGORY_TK is
'The foreign key to D_SCREEN_CATEGORY';

comment on column D_SCREEN.BUSINESS_AREA_TK is
'The foreign key to D_BUSINESS_AREA';

comment on column D_SCREEN.TABLE_TK is
'The foreign key to table (D_TABLE) for which the screen is applied; 
by definition a screen can be applied on one table at the time;
so multiple entries should be created, one for each table, for the same screen applied on different table.
If a given screen would record an incident - and records from multiple tables make up an incident,
they would be recorded in F_DQ_EVENT_DETAILS table, as data set causing an issue , 
but that incident is reported for the table defined by this field (TABLE_KEY)';

comment on column D_SCREEN.SCREEN_SPECIFIC_SQL is
'Field captures the view, actual snippet of SQL or procedural SQL 
used to execute the data-quality check. It''s only populated when SCREEN_GENERIC_VIEW_OR_SQL is not applicable';

comment on column D_SCREEN.ACTIVE is
'The flag used by the application to run a check or not; for example for Deleted columns or tables check should be disabled; 
and if check for some problematic columns might be disabled';

comment on column D_SCREEN.COLUMN_NAME is
'exact column name for wich column screen category is applied';

comment on column D_SCREEN.COLUMN_DELETED is
'The flag informing whether a column / table is deleted in EDW';

--==============================================================
-- Table: D_SCREEN_CATEGORY
--==============================================================
create table D_SCREEN_CATEGORY (
   SCREEN_CATEGORY_TK   BIGINT                         not null,
   SCREEN_CATAGORY      CHARACTER VARYING(50)          not null,
   SCREEN_TYPE          CHARACTER VARYING(50)          not null,
   SCREEN_NAME          CHARACTER VARYING(100)         null,
   SCREEN_DEFINITION    NATIONAL CHARACTER VARYING(255) null,
   SCREEN_SQL_TYPE      CHARACTER VARYING(50)          null,
   SCREEN_GENERIC_SQL   NATIONAL CHARACTER VARYING(2000) null,
   constraint PK_D_SCREEN_CATEGORY primary key (SCREEN_CATEGORY_TK)
)
distribute on random;

comment on table D_SCREEN_CATEGORY is
'Configuration table storing screen categories, types and generic definition.';

comment on column D_SCREEN_CATEGORY.SCREEN_CATEGORY_TK is
'Pirmary key - surrogate key';

comment on column D_SCREEN_CATEGORY.SCREEN_CATAGORY is
'3 categories: column screens, structure screens, and business rule screens. 
Column screens test the data within a single column. These are usually simple,
somewhat obvious tests, such as testing whether a column contains unexpected
null values, if a value falls outside of a prescribed range, or if a value fails to adhere
to a required format.
Structure screens test the relationship of data across columns. Two or more
attributes may be tested to verify they implement a hierarchy, such as a series of
many-to-one relationships. Structure screens also test foreign key/primary key relationships
between columns in two tables, and also include testing whole blocks of
columns to verify they implement valid postal addresses.
Business rule screens implement more complex tests that do not fit the simpler
column or structure screen categories. For example, whether source load , VDA, 
has been completely loaded or there are some gaps.  Business rule screens also include 
aggregate threshold data quality checks, such as checking to see if number of new loaded records
is very low, below expected threshold. In this case, the screen throws an error only after a threshold 
is not reached.';

comment on column D_SCREEN_CATEGORY.SCREEN_TYPE is
'It''s used to group data-quality screens related by theme, such as Completeness or Validation or Out-of-Bounds, Duplicate Key etc';

comment on column D_SCREEN_CATEGORY.SCREEN_NAME is
'Human identifier of the screen , for example: Duplicate_Current_Y_Flag_D_VEHICLE ';

comment on column D_SCREEN_CATEGORY.SCREEN_DEFINITION is
'Field defines what the screen should do / check - human explanation';

comment on column D_SCREEN_CATEGORY.SCREEN_SQL_TYPE is
'Informes whether check is applied via view, SQL snippet, or procedure; helps to interpret SCREEN_GENERIC_SQL';

comment on column D_SCREEN_CATEGORY.SCREEN_GENERIC_SQL is
'Field captures the view, actual snippet of SQL or procedural SQL 
used to execute the data-quality check. If applicable,  this SQL should return the set of unique identifiers for the rows that
violate the data-quality screen so that this can be used to insert new records into F_SCREEN_EVENTS';

--==============================================================
-- Table: D_TABLE
--==============================================================
create table D_TABLE (
   TABLE_TK             BIGINT                         not null,
   DATABASE_NAME        CHARACTER VARYING(50)          null,
   ENTITY_TYPE          CHARACTER VARYING(20)          null,
   NAME                 CHARACTER VARYING(255)         null,
   constraint PK_D_TABLE primary key (TABLE_TK)
);

comment on table D_TABLE is
'Dimension listing EDW tables; There needs to be one ''N/A'' record added for screens not applicable on table / view level.';

comment on column D_TABLE.TABLE_TK is
'Pirmary key - surrogate key
';

comment on column D_TABLE.DATABASE_NAME is
'Database name, with real environment prefix, for example PROD_PARTS_DM, PROD_EDW_STOV;
Potentially the checks might be applied on QA env, but on PROD copied data.';

comment on column D_TABLE.ENTITY_TYPE is
'"VIEW" or "TABLE"';

comment on column D_TABLE.NAME is
'Name of the view or table';

--==============================================================
-- Table: F_SCREEN_EVENTS
--==============================================================
create table F_SCREEN_EVENTS (
   SCREEN_RUN_TK        BIGINT                         not null,
   SCREEN_EVENT_NB		BIGINT                         not null,
   SCREEN_RUN_DATE_TK   BIGINT                         null,
   SCREEN_TK            BIGINT                         not null,
   SCREEN_RUN_TIME      TIMESTAMP                      null,
   TABLE_TK             BIGINT                         not null,
   FIELD_NAME           CHARACTER VARYING(255)         not null,
   TABLE_ROWID          BIGINT                         null,
   SCREEN_VIOLATION_CONDITION NATIONAL CHARACTER VARYING(500) null,
   constraint PK_F_SCREEN_EVENTS primary key (SCREEN_RUN_TK, SCREEN_EVENT_NB, SCREEN_TK, TABLE_TK, FIELD_NAME)
)
distribute on random;

comment on table F_SCREEN_EVENTS is
'Each data-quality vialation within a single screen is captured as a row in the event fact table. One screen can return as many records as there a table records for table / column screens. Sometimes one error is reflected by 2, 3 or more records for complex structure or business rule screen, where a single event generates many rows in this error event  fact table. Thus, SCREEN_EVENT_NB helps to group records accountable for one screen event. Most of the time however it will be one record per registered error, for example one record for each NULL record in specific column.';

comment on column F_SCREEN_EVENTS.SCREEN_RUN_TK is
'Foreign key to F_SCREEN_RUN';

comment on column F_SCREEN_EVENTS.SCREEN_EVENT_NB is
'It''s needed to server as grouping field for each screen violation case - there can be 10 vialations for one screen,
but number of returned records by the screen is 20 since 2 fields or tables make up for one vialation.';

comment on column F_SCREEN_EVENTS.SCREEN_RUN_DATE_TK is
'Foreign key to D_DATE; date when screen event is recorded';

comment on column F_SCREEN_EVENTS.SCREEN_TK is
'Foreign key to D_SCREEN table';

comment on column F_SCREEN_EVENTS.SCREEN_RUN_TIME is
'Time when record is added to the ';

comment on column F_SCREEN_EVENTS.TABLE_TK is
'Foreign key to D_TABLE for each table that participated in / caused screen violation';

comment on column F_SCREEN_EVENTS.FIELD_NAME is
'Each fields that participated in / caused screen violation';

comment on column F_SCREEN_EVENTS.TABLE_ROWID is
'ROWID  of the table that participated in screen violation';

comment on column F_SCREEN_EVENTS.SCREEN_VIOLATION_CONDITION is
'Description of the given screen run - free text . optionaly added to describe the given screen violation run';

--==============================================================
-- Table: F_SCREEN_RUN
--==============================================================
create table F_SCREEN_RUN (
   SCREEN_RUN_TK        BIGINT                         not null,
   SCREEN_TK            BIGINT                         null,
   SCREEN_RUN_DATE_TK   BIGINT                         not null,
   SCREEN_RUN_TIME      TIMESTAMP                      null,
   VIOLATED_RECORDS_QT  BIGINT                         null,
   TOTAL_RECORDS_QT     BIGINT                         null,
   constraint PK_F_SCREEN_RUN primary key (SCREEN_RUN_TK)
)
distribute on random;

comment on table F_SCREEN_RUN is
'Each row in this table correspondes to a screen run, giving details such as total number of error records, total number of good records etc.';

comment on column F_SCREEN_RUN.SCREEN_RUN_TK is
'Pirmary key - surrogate key;  one record per screen run';

comment on column F_SCREEN_RUN.SCREEN_TK is
'Foreign key to D_SCREEN table';

comment on column F_SCREEN_RUN.SCREEN_RUN_DATE_TK is
'Foreign key to D_DATE; date of the screen run';

comment on column F_SCREEN_RUN.SCREEN_RUN_TIME is
'Timestamp of the screen run';

comment on column F_SCREEN_RUN.VIOLATED_RECORDS_QT is
'Count of the records in F_SCREEN_EVENTS corresponding to a given screen run';

comment on column F_SCREEN_RUN.TOTAL_RECORDS_QT is
'total number of records from the table for which screen is run; can be useful to see ratio of good records';

alter table D_JOB_SCREEN add constraint FK_JOB_SCREEN_2_JOB foreign key (JOB_TK)
   references D_JOB (JOB_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table D_JOB_SCREEN add constraint FK_JOB_SCREEN_2_SCREEN foreign key (SCREEN_TK)
   references D_SCREEN (SCREEN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table D_SCREEN add constraint FK_SCREEN_2_BUSINESS_AREA foreign key (BUSINESS_AREA_TK)
   references D_BUSINESS_AREA (BUSINESS_AREA_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table D_SCREEN add constraint FK_SCREEN_2_TABLE foreign key (TABLE_TK)
   references D_TABLE (TABLE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table D_SCREEN add constraint FK_SCREEN_CATEGORY_2_SCREEN foreign key (SCREEN_CATEGORY_TK)
   references D_SCREEN_CATEGORY (SCREEN_CATEGORY_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_DATE foreign key (SCREEN_RUN_DATE_TK)
   references D_DATE (DATE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_SCREEN foreign key (SCREEN_TK)
   references D_SCREEN (SCREEN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_SCREEN_RUN foreign key (SCREEN_RUN_TK)
   references F_SCREEN_RUN (SCREEN_RUN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_TABLE foreign key (TABLE_TK)
   references D_TABLE (TABLE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_RUN add constraint FK_SCREEN_RUN_2_DATE foreign key (SCREEN_RUN_DATE_TK)
   references D_DATE (DATE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_RUN add constraint FK_SCREEN_RUN_2_SCREEN foreign key (SCREEN_TK)
   references D_SCREEN (SCREEN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

