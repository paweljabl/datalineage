drop table DEV_DWHU_STAGING..POC_WH_TAB_COLUMNS;
CREATE TABLE DEV_DWHU_STAGING..POC_WH_TAB_COLUMNS
(
  table_type varchar(64)	
, table_name varchar(64)
, table_active varchar(1)
, obj_key integer
, col_key integer
, col_name varchar(64)
, display_name varchar(256)
, data_type varchar(256)
, nulls_flag varchar(1)
, numeric_flag varchar(1)
, additive_flag varchar(1)
, attribute_flag varchar(1)
, col_format varchar(64)
, src_table varchar(64)
, src_column varchar(64)
, col_order integer
, key_type varchar(1)
, join_flag varchar(1)
, business_key_ind varchar(1)
, primary_index_ind varchar(1)
, default_value varchar(1024)
, case_flag varchar(1)
, title varchar(64)
, compress_flag varchar(1)
, comments varchar(256)
, col_type varchar(64)
, update_flag varchar(1)
, display_type varchar(64)
, pre_join_source varchar(64)
, ind_1 varchar(1)
)
;

select * from DEV_DWHU_STAGING..POC_WH_TAB_COLUMNS
;
