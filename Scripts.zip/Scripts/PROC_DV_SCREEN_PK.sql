CREATE OR REPLACE PROCEDURE PROC_DV_SCREEN_PK (VARARGS)
RETURNS CHARACTER VARYING(ANY)
LANGUAGE NZPLSQL 
AS
BEGIN_PROC
DECLARE

	--============================================================================
	-- Input variables
	--============================================================================
	
--	P_INPUT_VARIABLE_1 ALIAS FOR $1;
--	P_INPUT_VARIABLE_2 ALIAS FOR $2;

	--============================================================================
	-- Control variables used in most procedures
	--============================================================================

	V_MSGTEXT           VARCHAR(2000);  -- Text for audit_trail
	V_SQL               VARCHAR(4000);  -- Text for SQL statements
	V_STEP              INTEGER;       -- Indicator which part of the code was last executed when proc execution failed
	V_STEP_DESC			VARCHAR(255);  -- Description of the step (part of the code)
	V_INSERT_COUNT      BIGINT;        -- No of records inserted
	V_COUNT             BIGINT;        -- General counter
	V_ROW_COUNT			BIGINT;        -- General row count
	V_SQL_ERROR         VARCHAR(2000);  -- Sql error code for audit trail as varchar
	
	--============================================================================
	-- Procedure variables
	--============================================================================
	V_START_TIME TIMESTAMP;
	
BEGIN	
	
	--============================================================================
	V_STEP := 100;
	V_STEP_DESC := 'Initial variables setup / temp table creation with input';
	--============================================================================
	
	
	V_START_TIME := CURRENT_TIMESTAMP;
	
	CREATE TEMP TABLE TEMP_DV_SCREEN_PK AS 
	SELECT
	  'PK#' || W.TABLE_TK AS SCREEN_CODE
	, SC.SCREEN_CATEGORY_TK
	, W.TABLE_TK
	, 0 AS TABLE_COLUMN_TK
	, 'Unique columns: DV_VERSION, ' || UNIQUE_COLS AS SCREEN_DESCRIPTION
	, 'SELECT ' || W.TABLE_TK || ' AS TABLE_TK, R.ROWID AS TABLE_ROWID, G.SCREEN_EVENT_NB, NULL AS SCREEN_VIOLATION_CONDITION ' 
		|| CHR(10) || 'FROM ( ' 
		|| CHR(10) || CHR(9) || 'SELECT ' || UNIQUE_COLS || ', DV_VERSION'
		|| ', ROW_NUMBER() OVER (ORDER BY ' || UNIQUE_COLS || ', DV_VERSION) AS SCREEN_EVENT_NB'
		|| CHR(10) || CHR(9) || 'FROM ' || W.DATABASE_NAME || '..' || W.NAME 
		|| CHR(10) || CHR(9) || 'GROUP BY ' || UNIQUE_COLS || ', DV_VERSION'
		|| CHR(10) || CHR(9) || 'HAVING COUNT(*) > 1 ) G ' || CHR(10) || 'JOIN ' || W.DATABASE_NAME || '..' || W.NAME || ' R ON ' || JOIN_COND
		|| CHR(10) || CHR(9) || 'AND G.DV_VERSION = R.DV_VERSION' AS SCREEN_SPECIFIC_SQL
	, 'SELECT COUNT(*) AS TOTAL_RECORDS_QT FROM ' || W.DATABASE_NAME || '..' || W.NAME  AS TOTAL_RECORDS_QT_SQL
	, W.ENVIRONMENT AS ENVIRONMENT
	FROM D_SCREEN_CATEGORY SC
	CROSS JOIN (
	  SELECT ENVIRONMENT, DATABASE_NAME, NAME, TABLE_TK
	  , NVL(MAX(COL_0), '') || NVL(MAX(NVL2(COL_1, ', ' || COL_1, NULL)), '') || NVL(MAX(NVL2(COL_2, ', ' || COL_2, NULL)), '') 
	  || NVL(MAX(NVL2(COL_3, ', ' || COL_3, NULL)), '') || NVL(MAX(NVL2(COL_4, ', ' || COL_4, NULL)), '') || NVL(MAX(NVL2(COL_5, ', ' || COL_5, NULL)), '')
	  || NVL(MAX(NVL2(COL_6, ', ' || COL_6, NULL)), '') || NVL(MAX(NVL2(COL_7, ', ' || COL_7, NULL)), '') || NVL(MAX(NVL2(COL_8, ', ' || COL_8, NULL)), '') 
	  || NVL(MAX(NVL2(COL_9, ', ' || COL_9, NULL)), '') || NVL(MAX(NVL2(COL_10, ', ' || COL_10, NULL)), '') AS UNIQUE_COLS
	  , NVL('G.' || MAX(COL_0) || ' = R.' || MAX(COL_0), '') 
	  	|| NVL(MAX(NVL2(COL_1, ' AND G.' || COL_1 || ' = R.' || COL_1, NULL)), '')
	  	|| NVL(MAX(NVL2(COL_2, ' AND G.' || COL_2 || ' = R.' || COL_2, NULL)), '') 
		|| NVL(MAX(NVL2(COL_3, ' AND G.' || COL_3 || ' = R.' || COL_3, NULL)), '')
		|| NVL(MAX(NVL2(COL_4, ' AND G.' || COL_4 || ' = R.' || COL_4, NULL)), '') 
		|| NVL(MAX(NVL2(COL_5, ' AND G.' || COL_5 || ' = R.' || COL_5, NULL)), '')
		|| NVL(MAX(NVL2(COL_6, ' AND G.' || COL_6 || ' = R.' || COL_6, NULL)), '')
		|| NVL(MAX(NVL2(COL_7, ' AND G.' || COL_7 || ' = R.' || COL_7, NULL)), '')
		|| NVL(MAX(NVL2(COL_8, ' AND G.' || COL_8 || ' = R.' || COL_8, NULL)), '')
		|| NVL(MAX(NVL2(COL_9, ' AND G.' || COL_9 || ' = R.' || COL_9, NULL)), '')
		|| NVL(MAX(NVL2(COL_10, ' AND G.' || COL_10 || ' = R.' || COL_10, NULL)), '')
		AS JOIN_COND
	  FROM ( 
		  SELECT T.ENVIRONMENT 
		  , T.DATABASE_NAME
		  , T.NAME
		  , T.TABLE_TK
		  , CASE WHEN TC.BUSINESS_KEY_IND = '0' THEN COLUMN_NAME END AS COL_0
		  , CASE WHEN TC.BUSINESS_KEY_IND = '1' THEN COLUMN_NAME END AS COL_1
		  , CASE WHEN TC.BUSINESS_KEY_IND = '2' THEN COLUMN_NAME END AS COL_2
		  , CASE WHEN TC.BUSINESS_KEY_IND = '3' THEN COLUMN_NAME END AS COL_3
		  , CASE WHEN TC.BUSINESS_KEY_IND = '4' THEN COLUMN_NAME END AS COL_4
		  , CASE WHEN TC.BUSINESS_KEY_IND = '5' THEN COLUMN_NAME END AS COL_5
		  , CASE WHEN TC.BUSINESS_KEY_IND = '6' THEN COLUMN_NAME END AS COL_6
		  , CASE WHEN TC.BUSINESS_KEY_IND = '7' THEN COLUMN_NAME END AS COL_7
		  , CASE WHEN TC.BUSINESS_KEY_IND = '8' THEN COLUMN_NAME END AS COL_8
		  , CASE WHEN TC.BUSINESS_KEY_IND = '9' THEN COLUMN_NAME END AS COL_9
		  , CASE WHEN TC.BUSINESS_KEY_IND = 'a' THEN COLUMN_NAME END AS COL_10
		  FROM D_TABLE_COLUMN_DV TC
		  JOIN D_TABLE T ON TC.TABLE_TK = T.TABLE_TK
		  	AND T.OBJECT_TYPE_CODE IN ('SAT')
			AND TC.ENVIRONMENT = T.ENVIRONMENT
		  WHERE TC.BUSINESS_KEY_IND not in ('N', 'Y')
		  	AND TC.DELETE_FLAG = 'N'
	  ) A
	  GROUP BY ENVIRONMENT, DATABASE_NAME, NAME, TABLE_TK
	  ORDER BY ENVIRONMENT, DATABASE_NAME, NAME, TABLE_TK
	) W 
	WHERE SC.SCREEN_CATEGORY_CODE = 'PK'
	UNION ALL
	SELECT
	  'PK#' || W.TABLE_TK AS SCREEN_CODE
	, SC.SCREEN_CATEGORY_TK
	, W.TABLE_TK
	, 0 AS TABLE_COLUMN_TK
	, 'Unique columns: ' || UNIQUE_COLS AS SCREEN_DESCRIPTION
	, 'SELECT ' || W.TABLE_TK || ' AS TABLE_TK, R.ROWID AS TABLE_ROWID, G.SCREEN_EVENT_NB, NULL AS SCREEN_VIOLATION_CONDITION ' 
		|| CHR(10) || 'FROM ( ' 
		|| CHR(10) || CHR(9) || 'SELECT ' || UNIQUE_COLS 
		|| ', ROW_NUMBER() OVER (ORDER BY ' || UNIQUE_COLS || ') AS SCREEN_EVENT_NB'
		|| CHR(10) || CHR(9) || 'FROM ' || W.DATABASE_NAME || '..' || W.NAME 
		|| CHR(10) || CHR(9) || 'GROUP BY ' || UNIQUE_COLS 
		|| CHR(10) || CHR(9) || 'HAVING COUNT(*) > 1 ) G ' 
		|| CHR(10) || 'JOIN ' || W.DATABASE_NAME || '..' || W.NAME || ' R ON ' || JOIN_COND AS SCREEN_SPECIFIC_SQL
	, 'SELECT COUNT(*) AS TOTAL_RECORDS_QT FROM ' || W.DATABASE_NAME || '..' || W.NAME  AS TOTAL_RECORDS_QT_SQL
	, W.ENVIRONMENT AS ENVIRONMENT
	FROM D_SCREEN_CATEGORY SC
	CROSS JOIN (
	  SELECT ENVIRONMENT, DATABASE_NAME, NAME, TABLE_TK
	  , NVL(MAX(COL_0), '') || NVL(MAX(NVL2(COL_1, ', ' || COL_1, NULL)), '') || NVL(MAX(NVL2(COL_2, ', ' || COL_2, NULL)), '') 
	  || NVL(MAX(NVL2(COL_3, ', ' || COL_3, NULL)), '') || NVL(MAX(NVL2(COL_4, ', ' || COL_4, NULL)), '') || NVL(MAX(NVL2(COL_5, ', ' || COL_5, NULL)), '')
	  || NVL(MAX(NVL2(COL_6, ', ' || COL_6, NULL)), '') || NVL(MAX(NVL2(COL_7, ', ' || COL_7, NULL)), '') || NVL(MAX(NVL2(COL_8, ', ' || COL_8, NULL)), '') 
	  || NVL(MAX(NVL2(COL_9, ', ' || COL_9, NULL)), '') || NVL(MAX(NVL2(COL_10, ', ' || COL_10, NULL)), '') AS UNIQUE_COLS
	  , NVL('G.' || MAX(COL_0) || ' = R.' || MAX(COL_0), '') 
	  	|| NVL(MAX(NVL2(COL_1, ' AND G.' || COL_1 || ' = R.' || COL_1, NULL)), '')
	  	|| NVL(MAX(NVL2(COL_2, ' AND G.' || COL_2 || ' = R.' || COL_2, NULL)), '') 
		|| NVL(MAX(NVL2(COL_3, ' AND G.' || COL_3 || ' = R.' || COL_3, NULL)), '')
		|| NVL(MAX(NVL2(COL_4, ' AND G.' || COL_4 || ' = R.' || COL_4, NULL)), '') 
		|| NVL(MAX(NVL2(COL_5, ' AND G.' || COL_5 || ' = R.' || COL_5, NULL)), '')
		|| NVL(MAX(NVL2(COL_6, ' AND G.' || COL_6 || ' = R.' || COL_6, NULL)), '')
		|| NVL(MAX(NVL2(COL_7, ' AND G.' || COL_7 || ' = R.' || COL_7, NULL)), '')
		|| NVL(MAX(NVL2(COL_8, ' AND G.' || COL_8 || ' = R.' || COL_8, NULL)), '')
		|| NVL(MAX(NVL2(COL_9, ' AND G.' || COL_9 || ' = R.' || COL_9, NULL)), '')
		|| NVL(MAX(NVL2(COL_10, ' AND G.' || COL_10 || ' = R.' || COL_10, NULL)), '')
		AS JOIN_COND
	  FROM ( 
		  SELECT T.ENVIRONMENT 
		  , T.DATABASE_NAME
		  , T.NAME
		  , T.TABLE_TK
		  , CASE WHEN TC.BUSINESS_KEY_IND = '0' THEN COLUMN_NAME END AS COL_0
		  , CASE WHEN TC.BUSINESS_KEY_IND = '1' THEN COLUMN_NAME END AS COL_1
		  , CASE WHEN TC.BUSINESS_KEY_IND = '2' THEN COLUMN_NAME END AS COL_2
		  , CASE WHEN TC.BUSINESS_KEY_IND = '3' THEN COLUMN_NAME END AS COL_3
		  , CASE WHEN TC.BUSINESS_KEY_IND = '4' THEN COLUMN_NAME END AS COL_4
		  , CASE WHEN TC.BUSINESS_KEY_IND = '5' THEN COLUMN_NAME END AS COL_5
		  , CASE WHEN TC.BUSINESS_KEY_IND = '6' THEN COLUMN_NAME END AS COL_6
		  , CASE WHEN TC.BUSINESS_KEY_IND = '7' THEN COLUMN_NAME END AS COL_7
		  , CASE WHEN TC.BUSINESS_KEY_IND = '8' THEN COLUMN_NAME END AS COL_8
		  , CASE WHEN TC.BUSINESS_KEY_IND = '9' THEN COLUMN_NAME END AS COL_9
		  , CASE WHEN TC.BUSINESS_KEY_IND = 'a' THEN COLUMN_NAME END AS COL_10
		  FROM D_TABLE_COLUMN_DV TC
		  JOIN D_TABLE T ON TC.TABLE_TK = T.TABLE_TK
		  	AND T.OBJECT_TYPE_CODE IN ('HUB', 'LNK')
			AND TC.ENVIRONMENT = T.ENVIRONMENT
		  WHERE TC.BUSINESS_KEY_IND not in ('N', 'Y')
		  	AND TC.DELETE_FLAG = 'N'
	  ) A
	  GROUP BY ENVIRONMENT, DATABASE_NAME, NAME, TABLE_TK
	  ORDER BY ENVIRONMENT, DATABASE_NAME, NAME, TABLE_TK
	) W 
	WHERE SC.SCREEN_CATEGORY_CODE = 'PK'
	MINUS 
	SELECT S.SCREEN_CODE, S.SCREEN_CATEGORY_TK, S.TABLE_TK, S.TABLE_COLUMN_TK, S.SCREEN_DESCRIPTION, S.SCREEN_SPECIFIC_SQL, S.TOTAL_RECORDS_QT_SQL, ENVIRONMENT
	FROM D_SCREEN S
	WHERE S.SCREEN_CATEGORY_TK = (SELECT SCREEN_CATEGORY_TK FROM D_SCREEN_CATEGORY WHERE SCREEN_CATEGORY_CODE = 'PK')
		AND DELETE_FLAG = 'N'
		AND TABLE_TK IN (SELECT TABLE_TK 
			FROM D_TABLE
			WHERE TECHNICAL_AREA = 'Data Vault'
		)
	;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Total Screens to insert / update: %', V_STEP, V_STEP_DESC, V_ROW_COUNT;
	--============================================================================
	V_STEP := 200;
	V_STEP_DESC := 'Setting DELETE_FLAG in D_SCREEN to ''Y'' for screens with changed screen definition';
	--============================================================================
	
	UPDATE D_SCREEN S
		SET S.DELETE_FLAG = 'Y'
			, S.DM_UPDATE_TIMESTAMP = V_START_TIME
	WHERE S.SCREEN_CODE IN (SELECT SCREEN_CODE FROM TEMP_DV_SCREEN_PK)
	;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Updated records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	--============================================================================
	V_STEP := 300;
	V_STEP_DESC := 'Inserting new / changed screens to D_SCREEN';
	--============================================================================
	
	INSERT INTO D_SCREEN (SCREEN_TK, SCREEN_CODE, SCREEN_CATEGORY_TK, TABLE_TK, TABLE_COLUMN_TK, SCREEN_DESCRIPTION, SCREEN_SPECIFIC_SQL, NR_OF_EVENTS_2_RECORD, TOTAL_RECORDS_QT_SQL, SAVE_GOOD_RUN_TOTAL_COUNT, ACTIVE, DELETE_FLAG, ENVIRONMENT, DM_INSERT_TIMESTAMP)
	SELECT NEXT VALUE FOR D_SCREEN_SEQ
	, U.SCREEN_CODE
	, U.SCREEN_CATEGORY_TK
	, U.TABLE_TK
	, U.TABLE_COLUMN_TK
	, CASE 
		WHEN LENGTH(U.SCREEN_DESCRIPTION) > 250 THEN SUBSTR(U.SCREEN_DESCRIPTION, 250) || '...' 
		ELSE U.SCREEN_DESCRIPTION END AS SCREEN_DESCRIPTION  
	, U.SCREEN_SPECIFIC_SQL
	, 10 AS NR_OF_EVENTS_2_RECORD
	, U.TOTAL_RECORDS_QT_SQL
	, 'N' AS SAVE_GOOD_RUN_TOTAL_COUNT
	, 'Y' AS ACTIVE
	, 'N' AS DELETE_FLAG
	, U.ENVIRONMENT
	, V_START_TIME AS DM_INSERT_TIMESTAMP
	FROM TEMP_DV_SCREEN_PK U
	;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Inserted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	--============================================================================
	V_STEP := 400;
	V_STEP_DESC := 'Setting DELETE_FLAG in D_SCREEN to ''Y'' for screens on tables / columns that no longer exist';
	--============================================================================
	
	UPDATE D_SCREEN S
		SET S.DELETE_FLAG = 'Y'
			, S.DM_UPDATE_TIMESTAMP = V_START_TIME
	FROM (
		SELECT TABLE_TK FROM D_TABLE
		WHERE TECHNICAL_AREA = 'Data Vault'
			AND DELETE_FLAG = 'Y'
		UNION
		SELECT DISTINCT TABLE_TK 
		FROM D_TABLE_COLUMN_DV 
		WHERE BUSINESS_KEY_IND NOT IN ('N', 'Y') 
			AND DELETE_FLAG = 'Y' 
	) T
	WHERE S.SCREEN_CATEGORY_TK = (SELECT SCREEN_CATEGORY_TK FROM D_SCREEN_CATEGORY WHERE SCREEN_CATEGORY_CODE = 'PK')
		AND S.DELETE_FLAG = 'N'
		AND T.TABLE_TK = S.TABLE_TK	
	;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Updated records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	--============================================================================
	V_STEP := 500;
	V_STEP_DESC := 'Drop temp tables';
	--============================================================================
	
	DROP TABLE TEMP_DV_SCREEN_PK IF EXISTS;
	RAISE NOTICE 'Step: % (%)', V_STEP, V_STEP_DESC ;
	
--============================================================================
-- Final settings
--============================================================================

RETURN '1';

EXCEPTION
WHEN OTHERS THEN
  V_SQL_ERROR := SQLERRM;
  V_MSGTEXT := 'Step: ' || V_STEP || ' (' || V_STEP_DESC || ')';
  RAISE NOTICE 'Screen run exception: %; Sql error: %' ,V_MSGTEXT, V_SQL_ERROR;
  DROP TABLE TEMP_DV_SCREEN_PK IF EXISTS;
	
  RETURN '0, ' || V_MSGTEXT || '; ' || V_SQL_ERROR;
  
END;
END_PROC;
