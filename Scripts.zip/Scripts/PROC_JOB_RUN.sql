CREATE OR REPLACE PROCEDURE PROC_JOB_RUN(VARCHAR(50), VARCHAR(4), BIGINT)
RETURNS CHARACTER VARYING(ANY)
LANGUAGE NZPLSQL 
AS
BEGIN_PROC
DECLARE

	--============================================================================
	-- Input variables
	--============================================================================
	
	P_JOB_NAME ALIAS FOR $1;
	P_ENV ALIAS FOR $2;
	P_BATCH_ID ALIAS FOR $3;
	
	--============================================================================
	-- Control variables used in most procedures
	--============================================================================
	
	V_STATUS            INTEGER;       -- Overall result status. 1=okay
	V_RETURN_MSG        VARCHAR(4000);  -- Overall result message
	V_MSGTEXT           VARCHAR(4000);  -- Text for audit_trail
	V_SQL               VARCHAR(4000);  -- Text for SQL statements
	V_STEP              INTEGER;       -- Indicator which part of the code was last executed when proc execution failed
	V_STEP_DESC			VARCHAR(255);  -- Description of the step (part of the code)
	V_INSERT_COUNT      BIGINT;        -- No of records inserted
	V_COUNT             BIGINT;        -- General counter
	V_ROW_COUNT			BIGINT;        -- General row count
	V_SQL_ERROR         VARCHAR(4000);  -- Sql error code for audit trail as varchar
	
	--============================================================================
	-- Procedure variables
	--============================================================================
	V_JOB_TK BIGINT;
	V_JOB_RUN_TK BIGINT;
	V_START_TIME TIMESTAMP;
	V_ALL_SCREENS_SUCCESS CHAR(1);
	V_JOB_DESCRIPTION VARCHAR(255);
	V_TOTAL_SCREENS	INT;
	V_REC RECORD;
	V_SCREEN_TK BIGINT;
	
BEGIN
	
	--============================================================================
	V_STEP := 50;
	V_STEP_DESC := 'Checking validity of the environment input variable';
	--============================================================================
	
	IF P_ENV NOT IN ('DEV', 'TST', 'QA', 'PROD') THEN 
		RAISE EXCEPTION 'Second input variable should be one of: DEV, TST, QA, PROD';
	END IF;
	
	--============================================================================
	V_STEP := 100;
	V_STEP_DESC := 'Initial variables setup';
	--============================================================================
	
	V_START_TIME := CURRENT_TIMESTAMP;
	V_ALL_SCREENS_SUCCESS := 'Y';
	
	SELECT J.JOB_TK, J.JOB_DESCRIPTION INTO V_JOB_TK, V_JOB_DESCRIPTION
	FROM D_JOB J
	WHERE JOB_NAME = P_JOB_NAME;
	
	SELECT COUNT(*) INTO V_TOTAL_SCREENS
	FROM H_JOB_SCREEN H
	JOIN D_SCREEN S ON H.SCREEN_TK = S.SCREEN_TK
	WHERE H.JOB_TK = V_JOB_TK
		AND H.ENVIRONMENT = P_ENV
		AND S.ACTIVE = 'Y';
	
	
	V_JOB_RUN_TK := NEXT VALUE FOR F_JOB_RUN_SEQ;
	
	RAISE NOTICE 'V_JOB_TK: %, V_TOTAL_SCREENS: %, V_JOB_RUN_TK: %', V_JOB_TK, V_TOTAL_SCREENS, V_JOB_RUN_TK;
	--============================================================================
	V_STEP := 200;
	V_STEP_DESC := 'Checking input parameters';
	--============================================================================
	
	IF V_JOB_TK IS NULL THEN 
		RAISE EXCEPTION 'There''s no job defined in D_JOB for job: %', P_JOB_NAME;
	END IF;
	
	IF V_TOTAL_SCREENS = 0 THEN 
		RAISE EXCEPTION 'There are no screens defined in H_JOB_SCREEN for job: %', P_JOB_NAME;
	END IF;
	
	
	--============================================================================
	V_STEP := 300;
	V_STEP_DESC := 'Screens loop start';
	--============================================================================

	FOR V_REC IN SELECT H.* 
		FROM H_JOB_SCREEN H 
		JOIN D_SCREEN S ON H.SCREEN_TK = S.SCREEN_TK
		WHERE H.JOB_TK = V_JOB_TK 
			AND H.ENVIRONMENT = P_ENV 
			AND S.ACTIVE = 'Y'
		ORDER BY PROCESSING_ORDER_NB LOOP
	BEGIN
	
		--============================================================================
		V_STEP := 400;
		V_STEP_DESC := 'Calling Screen Run procedure';
		--============================================================================
	
		V_SCREEN_TK := V_REC.SCREEN_TK;
		RAISE NOTICE 'Calling PROC_SCREEN_RUN for %', V_SCREEN_TK;
		V_RETURN_MSG := PROC_SCREEN_RUN(V_SCREEN_TK, V_JOB_TK, V_JOB_RUN_TK) ;
		RAISE NOTICE 'V_RETURN_MSG: %', V_RETURN_MSG;
		V_STATUS := SUBSTR(V_RETURN_MSG, 1, 1);
		COMMIT;
		
		--============================================================================
		V_STEP := 500;
		V_STEP_DESC := 'Logging Error Screen Execution';
		--============================================================================		
		
		IF V_STATUS = 0 THEN
			INSERT INTO L_JOB_RUN_ERRORS (SCREEN_RUN_TIMESTAMP
		       , SCREEN_TK
		       , JOB_TK
		       , SQL_ERROR
			) VALUES (CURRENT_TIMESTAMP
		       , V_SCREEN_TK
		       , V_JOB_TK
		       , SUBSTR(V_RETURN_MSG, 3)
			);
			
			V_ALL_SCREENS_SUCCESS := 'N';
		END IF;
		
	END;
	END LOOP;
	
	--============================================================================
	V_STEP := 600;
	V_STEP_DESC := 'Populating F_JOB_RUN';
	--============================================================================
	
	INSERT INTO F_JOB_RUN (JOB_RUN_TK
		, JOB_TK
		, ENVIRONMENT
		, JOB_RUN_START_TIMESTAMP
		, JOB_RUN_END_TIMESTAMP
		, ALL_SCREENS_SUCCESS
		, BATCH_ID
	) VALUES ( V_JOB_RUN_TK
		, V_JOB_TK
		, P_ENV
		, V_START_TIME
		, CURRENT_TIMESTAMP
		, V_ALL_SCREENS_SUCCESS
		, P_BATCH_ID);

--============================================================================
-- Final settings
--============================================================================

RETURN V_JOB_RUN_TK;

EXCEPTION
WHEN OTHERS THEN
  V_SQL_ERROR := SQLERRM;
  V_MSGTEXT := 'JOB_NAME: ' || NVL(P_JOB_NAME, '')
  	|| ' (' || NVL(V_JOB_DESCRIPTION, '') || '); '
	|| 'Step: ' || V_STEP || ' (' || V_STEP_DESC || ')';
  RAISE NOTICE 'Job run exception: %; Sql error: %' ,V_MSGTEXT, V_SQL_ERROR;
  RETURN '0, ' || V_MSGTEXT || '; ' || V_SQL_ERROR;

	
END;
END_PROC;


/*
SELECT * FROM D_SCREEN

SELECT 42400001 AS TABLE_TK, R.ROWID, G.SCREEN_EVENT_NB, NULL AS SCREEN_VIOLATION_CONDITION 
FROM ( 
	SELECT HUB_SYNC_PURCHASE_ORDER_SID, DV_VERSION, ROW_NUMBER() OVER (ORDER BY HUB_SYNC_PURCHASE_ORDER_SID, DV_VERSION) AS SCREEN_EVENT_NB
	FROM DEV_EDW_DATAVAULT..SAT_GPS_SYNC_PURCHASE_ORDER
	GROUP BY HUB_SYNC_PURCHASE_ORDER_SID, DV_VERSION
	HAVING COUNT(*) > 1 ) G 
JOIN DEV_EDW_DATAVAULT..SAT_GPS_SYNC_PURCHASE_ORDER R ON G.HUB_SYNC_PURCHASE_ORDER_SID = R.HUB_SYNC_PURCHASE_ORDER_SID
	AND G.DV_VERSION = R.DV_VERSION
	
*/
