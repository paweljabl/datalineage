CALL PROC_DV_METADATA_REFRESH();

/*
CALL PROC_DV_TABLE_REFRESH('DEV');
CALL PROC_DV_TABLE_COLUMN_REFRESH('DEV');
CALL PROC_DV_TABLE_COLUMN_DV_REFRESH('DEV');

CALL PROC_DV_TABLE_RELATION_REFRESH();
CALL PROC_DV_SCREEN_PK();
CALL PROC_DV_SCREEN_DV_CUR_F();
CALL PROC_DV_SCREEN_DV_SID();

CALL PROC_DV_JOB_REFRESH();
CALL PROC_DV_JOB_SCREEN_REFRESH();
*/

/*
select distinct j.job_name from H_JOB_SCREEN h left join d_job j on j.job_tk = h.job_tk  
select substr(screen_code, 1, 2), screen_category_tk, count(*) from d_screen group by substr(screen_code, 1, 2) , screen_category_tk
select * from d_table where delete_flag = 'Y';
select distinct relation_type from D_TABLE_RELATION;
select * from d_screen;

SELECT DATABASE_NAME, NAME
FROM D_TABLE 
GROUP BY DATABASE_NAME, NAME
HAVING COUNT(*) > 1
*/



