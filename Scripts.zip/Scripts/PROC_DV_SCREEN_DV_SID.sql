CREATE OR REPLACE PROCEDURE PROC_DV_SCREEN_DV_SID (VARARGS)
RETURNS CHARACTER VARYING(ANY)
LANGUAGE NZPLSQL 
AS
BEGIN_PROC
DECLARE

	--============================================================================
	-- Input variables
	--============================================================================
	
--	P_INPUT_VARIABLE_1 ALIAS FOR $1;
--	P_INPUT_VARIABLE_2 ALIAS FOR $2;

	--============================================================================
	-- Control variables used in most procedures
	--============================================================================

	V_MSGTEXT           VARCHAR(2000);  -- Text for audit_trail
	V_SQL               VARCHAR(4000);  -- Text for SQL statements
	V_STEP              INTEGER;       -- Indicator which part of the code was last executed when proc execution failed
	V_STEP_DESC			VARCHAR(255);  -- Description of the step (part of the code)
	V_INSERT_COUNT      BIGINT;        -- No of records inserted
	V_COUNT             BIGINT;        -- General counter
	V_ROW_COUNT			BIGINT;        -- General row count
	V_SQL_ERROR         VARCHAR(2000);  -- Sql error code for audit trail as varchar
	V_RETURN_MSG		VARCHAR(4000);  -- Overall result message
	V_STATUS			INTEGER;       -- Overall result status. 1=okay
	--============================================================================
	-- Procedure variables
	--============================================================================
	V_START_TIME TIMESTAMP;
	
BEGIN	
	
	--============================================================================
	V_STEP := 100;
	V_STEP_DESC := 'Initial variables setup / temp table creation with input';
	--============================================================================
	
	V_START_TIME := CURRENT_TIMESTAMP;
	
	CREATE TEMP TABLE TEMP_SCREEN AS 
	SELECT
	  'DV_SID#' || W.TABLE_TK AS SCREEN_CODE
	, SC.SCREEN_CATEGORY_TK
	, W.TABLE_TK
	, 0 AS TABLE_COLUMN_TK
	, 'SID column values shouldn''t be 0' AS SCREEN_DESCRIPTION
	, 'SELECT ' || W.TABLE_TK || ' AS TABLE_TK, G.ROWID AS TABLE_ROWID'
		|| ', DENSE_RANK() OVER (ORDER BY ' || W.UNIQUE_COLS_G || ') AS SCREEN_EVENT_NB, NULL AS SCREEN_VIOLATION_CONDITION ' 
		|| CHR(10) ||  'FROM ' || W.DATABASE_NAME || '..' || W.NAME || ' G '
		|| CHR(10) || 'WHERE ' || W.WHERE_COND AS SCREEN_SPECIFIC_SQL
	, 'SELECT COUNT(*) AS TOTAL_RECORDS_QT FROM ' || W.DATABASE_NAME || '..' || W.NAME  AS TOTAL_RECORDS_QT_SQL
	, W.ENVIRONMENT AS ENVIRONMENT
	FROM D_SCREEN_CATEGORY SC
	CROSS JOIN (
	  SELECT ENVIRONMENT, DATABASE_NAME, NAME, TABLE_TK
	  , NVL('G.' || MAX(COL_0), '') || NVL(MAX(NVL2(COL_1, ', G.' || COL_1, NULL)), '') || NVL(MAX(NVL2(COL_2, ', G.' || COL_2, NULL)), '') 
		|| NVL(MAX(NVL2(COL_3, ', G.' || COL_3, NULL)), '') || NVL(MAX(NVL2(COL_4, ', G.' || COL_4, NULL)), '') || NVL(MAX(NVL2(COL_5, ', G.' || COL_5, NULL)), '')
		|| NVL(MAX(NVL2(COL_6, ', G.' || COL_6, NULL)), '') || NVL(MAX(NVL2(COL_7, ', G.' || COL_7, NULL)), '') || NVL(MAX(NVL2(COL_8, ', G.' || COL_8, NULL)), '') 
		|| NVL(MAX(NVL2(COL_9, ', G.' || COL_9, NULL)), '') || NVL(MAX(NVL2(COL_10, ', G.' || COL_10, NULL)), '') AS UNIQUE_COLS_G
	  , NVL('G.' || MAX(COL_0) || ' = 0', '') 
	  	|| NVL(MAX(NVL2(COL_1, ' OR G.' || COL_1 || ' = 0', NULL)), '')
	  	|| NVL(MAX(NVL2(COL_2, ' OR G.' || COL_2 || ' = 0', NULL)), '')
		|| NVL(MAX(NVL2(COL_3, ' OR G.' || COL_3 || ' = 0', NULL)), '')
		|| NVL(MAX(NVL2(COL_4, ' OR G.' || COL_4 || ' = 0', NULL)), '') 
		|| NVL(MAX(NVL2(COL_5, ' OR G.' || COL_5 || ' = 0', NULL)), '') 
		|| NVL(MAX(NVL2(COL_6, ' OR G.' || COL_6 || ' = 0', NULL)), '') 
		|| NVL(MAX(NVL2(COL_7, ' OR G.' || COL_7 || ' = 0', NULL)), '') 
		|| NVL(MAX(NVL2(COL_8, ' OR G.' || COL_8 || ' = 0', NULL)), '') 
		|| NVL(MAX(NVL2(COL_9, ' OR G.' || COL_9 || ' = 0', NULL)), '') 
		|| NVL(MAX(NVL2(COL_10, ' OR G.' || COL_10 || ' = 0', NULL)), '') AS WHERE_COND
	  FROM ( 
		  SELECT T.ENVIRONMENT 
		  , T.DATABASE_NAME
		  , T.NAME
		  , T.TABLE_TK
		  , CASE WHEN TC.BUSINESS_KEY_IND = '0' THEN COLUMN_NAME END AS COL_0
		  , CASE WHEN TC.BUSINESS_KEY_IND = '1' THEN COLUMN_NAME END AS COL_1
		  , CASE WHEN TC.BUSINESS_KEY_IND = '2' THEN COLUMN_NAME END AS COL_2
		  , CASE WHEN TC.BUSINESS_KEY_IND = '3' THEN COLUMN_NAME END AS COL_3
		  , CASE WHEN TC.BUSINESS_KEY_IND = '4' THEN COLUMN_NAME END AS COL_4
		  , CASE WHEN TC.BUSINESS_KEY_IND = '5' THEN COLUMN_NAME END AS COL_5
		  , CASE WHEN TC.BUSINESS_KEY_IND = '6' THEN COLUMN_NAME END AS COL_6
		  , CASE WHEN TC.BUSINESS_KEY_IND = '7' THEN COLUMN_NAME END AS COL_7
		  , CASE WHEN TC.BUSINESS_KEY_IND = '8' THEN COLUMN_NAME END AS COL_8
		  , CASE WHEN TC.BUSINESS_KEY_IND = '9' THEN COLUMN_NAME END AS COL_9
		  , CASE WHEN TC.BUSINESS_KEY_IND = 'a' THEN COLUMN_NAME END AS COL_10
		  FROM D_TABLE_COLUMN_DV TC
		  JOIN D_TABLE T ON TC.TABLE_TK = T.TABLE_TK
		  	AND T.OBJECT_TYPE_CODE IN ('SAT', 'LNK')
			AND TC.ENVIRONMENT = T.ENVIRONMENT
		  WHERE TC.BUSINESS_KEY_IND NOT IN ('N', 'Y')
		  	AND TC.DELETE_FLAG = 'N'
	  ) A
	  GROUP BY ENVIRONMENT, DATABASE_NAME, NAME, TABLE_TK
	  ORDER BY ENVIRONMENT, DATABASE_NAME, NAME, TABLE_TK
	) W 
	WHERE SC.SCREEN_CATEGORY_CODE = 'DV_SID'
	;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Total Screens: %', V_STEP, V_STEP_DESC, V_ROW_COUNT;
	--============================================================================
	V_STEP := 200;
	V_STEP_DESC := 'Calling PROC_SCREEN_UPDATE to refresh screens';
	--============================================================================
	
	V_RETURN_MSG := PROC_SCREEN_UPDATE('DV_SID');
	V_STATUS := SUBSTR(V_RETURN_MSG, 1, 1);
	IF V_STATUS = 0 THEN
		RAISE EXCEPTION '%', V_RETURN_MSG;
	END IF;	
	
--============================================================================
-- Final settings
--============================================================================

RETURN '1';

EXCEPTION
WHEN OTHERS THEN
  V_SQL_ERROR := SQLERRM;
  V_MSGTEXT := 'Step: ' || V_STEP || ' (' || V_STEP_DESC || ')';
  RAISE NOTICE 'Screen run exception: %; Sql error: %' ,V_MSGTEXT, V_SQL_ERROR;
  DROP TABLE TEMP_SCREEN_NEW IF EXISTS;
  DROP TABLE TEMP_SCREEN IF EXISTS;
	
  RETURN '0, ' || V_MSGTEXT || '; ' || V_SQL_ERROR;
  
END;
END_PROC;
