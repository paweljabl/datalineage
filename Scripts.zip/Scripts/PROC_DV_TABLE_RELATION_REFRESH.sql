CREATE OR REPLACE PROCEDURE PROC_DV_TABLE_RELATION_REFRESH (VARARGS)
RETURNS CHARACTER VARYING(ANY)
LANGUAGE NZPLSQL 
AS
BEGIN_PROC
DECLARE

	--============================================================================
	-- Input variables
	--============================================================================
	
--	P_ENV ALIAS FOR $1;
--	P_INPUT_VARIABLE_2 ALIAS FOR $2;

	--============================================================================
	-- Control variables used in most procedures
	--============================================================================

	V_MSGTEXT           VARCHAR(2000);  -- Text for audit_trail
	V_SQL               VARCHAR(4000);  -- Text for SQL statements
	V_STEP              INTEGER;       -- Indicator which part of the code was last executed when proc execution failed
	V_STEP_DESC			VARCHAR(255);  -- Description of the step (part of the code)
	V_INSERT_COUNT      BIGINT;        -- No of records inserted
	V_COUNT             BIGINT;        -- General counter
	V_ROW_COUNT			BIGINT;        -- General row count
	V_SQL_ERROR         VARCHAR(2000);  -- Sql error code for audit trail as varchar
	
	--============================================================================
	-- Procedure variables
	--============================================================================
	V_START_TIME TIMESTAMP;
	
BEGIN AUTOCOMMIT ON 
	
	--============================================================================
	V_STEP := 100;
	V_STEP_DESC := 'Initial variables setup, stats refresh, temp table truncate';
	--============================================================================
	
	V_START_TIME := CURRENT_TIMESTAMP;
	
	TRUNCATE TABLE TMP_TABLE_RELATION;
	
--	SET CATALOG D_TABLE_COLUMN_DV;
	GENERATE STATISTICS ON D_TABLE_COLUMN_DV;
	
	RAISE NOTICE 'Step: % (%)', V_STEP, V_STEP_DESC;
	--============================================================================
	V_STEP := 200;
	V_STEP_DESC := 'Populating TMP_TABLE_RELATION for HUB 2 SAT';
	--============================================================================
	
	/***** HUB 2 SAT *****/
	INSERT INTO TMP_TABLE_RELATION (TABLE_TK_A, ORDER_NB, TABLE_COLUMN_TK_A, TABLE_TK_B, TABLE_COLUMN_TK_B, RELATION_TYPE, RELATION_LEVEL)
	SELECT DISTINCT
		  S.TABLE_TK 
		, ROW_NUMBER() OVER (PARTITION BY S.TABLE_TK, H.TABLE_TK ORDER BY S.BUSINESS_KEY_IND) AS ORDER_NB
		, S.TABLE_COLUMN_TK   
		, H.TABLE_TK
		, H.TABLE_COLUMN_TK   
		, 'FK_PK' 
		, 1
	FROM D_TABLE_COLUMN_DV S
	JOIN D_TABLE_COLUMN_DV H ON UPPER(S.SRC_TABLE) = H.TABLE_NAME
		AND UPPER(S.SRC_COLUMN) = H.COLUMN_NAME
		AND H.OBJECT_TYPE_CODE = 'HUB'
		AND S.ENVIRONMENT = H.ENVIRONMENT
	WHERE S.DELETE_FLAG = 'N' AND H.DELETE_FLAG = 'N' 
		AND S.BUSINESS_KEY_IND not in ('N', 'Y')
		AND S.OBJECT_TYPE_CODE = 'SAT'
	--	AND UPPER(SUBSTR(S.SRC_TABLE, 1, 3)) IN ('HUB', 'REF')
		AND S.TABLE_TK IS NOT NULL
	ORDER BY S.TABLE_TK, ORDER_NB
	;
	
	V_ROW_COUNT :=  ROW_COUNT;
	RAISE NOTICE 'Step: % (%); Inserted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT;
	--============================================================================
	V_STEP := 300;
	V_STEP_DESC := 'Populating TMP_TABLE_RELATION for LNK 2 SAT';
	--============================================================================

	/***** LNK 2 SAT *****/
	INSERT INTO TMP_TABLE_RELATION (TABLE_TK_A, ORDER_NB, TABLE_COLUMN_TK_A, TABLE_TK_B, TABLE_COLUMN_TK_B, RELATION_TYPE, RELATION_LEVEL)
	SELECT DISTINCT
		  S.TABLE_TK 
		, ROW_NUMBER() OVER (PARTITION BY S.TABLE_TK, H.TABLE_TK ORDER BY S.BUSINESS_KEY_IND) AS ORDER_NB  
		, S.TABLE_COLUMN_TK   
		, H.TABLE_TK
		, H.TABLE_COLUMN_TK   
		, 'FK_PK' 
		, 1
	FROM D_TABLE_COLUMN_DV S
	JOIN D_TABLE_COLUMN_DV H ON UPPER(S.SRC_TABLE) = H.TABLE_NAME
		AND UPPER(S.SRC_COLUMN) = H.COLUMN_NAME
		AND H.OBJECT_TYPE_CODE = 'LNK'
		AND S.ENVIRONMENT = H.ENVIRONMENT
	WHERE S.DELETE_FLAG = 'N' AND H.DELETE_FLAG = 'N' 
		AND S.BUSINESS_KEY_IND not in ('N', 'Y')
		AND S.OBJECT_TYPE_CODE = 'SAT'
		AND S.TABLE_TK IS NOT NULL
	;

	V_ROW_COUNT :=  ROW_COUNT;
	RAISE NOTICE 'Step: % (%); Inserted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT;
	--============================================================================
	V_STEP := 400;
	V_STEP_DESC := 'Populating TMP_TABLE_RELATION for STG 2 LNK';
	--============================================================================

	/***** STG 2 LNK *****/
	INSERT INTO TMP_TABLE_RELATION (TABLE_TK_A, ORDER_NB, TABLE_COLUMN_TK_A, TABLE_TK_B, TABLE_COLUMN_TK_B, RELATION_TYPE, RELATION_LEVEL)
	SELECT DISTINCT
		  S.TABLE_TK 
		, ROW_NUMBER() OVER (PARTITION BY S.TABLE_TK, H.TABLE_TK ORDER BY S.BUSINESS_KEY_IND) AS ORDER_NB
		, S.TABLE_COLUMN_TK   
		, H.TABLE_TK
		, H.TABLE_COLUMN_TK   
		, 'FK_PK' 
		, 1
	FROM D_TABLE_COLUMN_DV S
	JOIN D_TABLE_COLUMN_DV H ON UPPER(S.SRC_TABLE) = H.TABLE_NAME
		AND UPPER(S.SRC_COLUMN) = H.COLUMN_NAME
		AND H.OBJECT_TYPE_CODE = 'STAGE'
		AND S.ENVIRONMENT = H.ENVIRONMENT
	WHERE S.DELETE_FLAG = 'N' AND H.DELETE_FLAG = 'N'
		AND S.BUSINESS_KEY_IND not in ('N', 'Y')
		AND S.OBJECT_TYPE_CODE = 'LNK'
		AND S.TABLE_TK IS NOT NULL
	;

	V_ROW_COUNT :=  ROW_COUNT;
	RAISE NOTICE 'Step: % (%); Inserted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT;
	--============================================================================
	V_STEP := 500;
	V_STEP_DESC := 'Populating TMP_TABLE_RELATION for HUB 2 STG';
	--============================================================================

	/***** HUB 2 STG *****/
	INSERT INTO TMP_TABLE_RELATION (TABLE_TK_A, ORDER_NB, TABLE_COLUMN_TK_A, TABLE_TK_B, TABLE_COLUMN_TK_B, RELATION_TYPE, RELATION_LEVEL)
	SELECT DISTINCT
		  S.TABLE_TK 
		, ROW_NUMBER() OVER (PARTITION BY S.TABLE_TK, H.TABLE_TK ORDER BY S.BUSINESS_KEY_IND) AS ORDER_NB	  
		, S.TABLE_COLUMN_TK   
		, H.TABLE_TK
		, H.TABLE_COLUMN_TK   
		, 'FK_PK' 
		, 1
	FROM D_TABLE_COLUMN_DV S
	JOIN D_TABLE_COLUMN_DV H ON UPPER(S.SRC_TABLE) = H.TABLE_NAME
		AND UPPER(S.SRC_COLUMN) = H.COLUMN_NAME
		AND H.OBJECT_TYPE_CODE = 'HUB'
		AND S.ENVIRONMENT = H.ENVIRONMENT
	WHERE S.DELETE_FLAG = 'N' AND H.DELETE_FLAG = 'N'
		AND S.BUSINESS_KEY_IND not in ('N', 'Y')
		AND S.OBJECT_TYPE_CODE = 'STAGE'
		AND S.TABLE_TK IS NOT NULL
	;

	V_ROW_COUNT :=  ROW_COUNT;
	RAISE NOTICE 'Step: % (%); Inserted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT;
	--============================================================================
	V_STEP := 600;
	V_STEP_DESC := 'Populating TMP_TABLE_RELATION for HUB 2 LNK';
	--============================================================================

	/***** HUB 2 LNK *****/
	INSERT INTO TMP_TABLE_RELATION (TABLE_TK_A, ORDER_NB, TABLE_TK_B, RELATION_TYPE, RELATION_LEVEL)
	SELECT DISTINCT
		  TS.TABLE_TK
		, 1 AS ORDER_NB
		, TH.TABLE_TK
		, 'FK_PK_I' 
		, 2
	FROM TMP_TABLE_RELATION H
	JOIN D_TABLE TH ON H.TABLE_TK_B = TH.TABLE_TK
		AND TH.OBJECT_TYPE_CODE = 'HUB'
	JOIN TMP_TABLE_RELATION S ON S.TABLE_TK_B = H.TABLE_TK_A
	JOIN D_TABLE TS ON S.TABLE_TK_A = TS.TABLE_TK
		AND TS.OBJECT_TYPE_CODE = 'LNK'
	;

	V_ROW_COUNT :=  ROW_COUNT;
	RAISE NOTICE 'Step: % (%); Inserted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT;
	--============================================================================
	V_STEP := 700;
	V_STEP_DESC := 'Populating TMP_TABLE_RELATION for HUB 2 SAT';
	--============================================================================

	/***** HUB 2 SAT through LNK *****/
	INSERT INTO TMP_TABLE_RELATION (TABLE_TK_A, ORDER_NB, TABLE_TK_B, RELATION_TYPE, RELATION_LEVEL)
	SELECT DISTINCT
		  TS.TABLE_TK
		, 1 AS ORDER_NB
		, TH.TABLE_TK
		, 'FK_PK_I' 
		, 3
	FROM TMP_TABLE_RELATION H
	JOIN D_TABLE TH ON H.TABLE_TK_B = TH.TABLE_TK
		AND TH.OBJECT_TYPE_CODE = 'HUB'
	JOIN TMP_TABLE_RELATION S ON S.TABLE_TK_B = H.TABLE_TK_A
	JOIN D_TABLE TS ON S.TABLE_TK_A = TS.TABLE_TK
		AND TS.OBJECT_TYPE_CODE = 'SAT'
	WHERE H.RELATION_LEVEL = 2
	;

	V_ROW_COUNT :=  ROW_COUNT;
	RAISE NOTICE 'Step: % (%); Inserted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT;

	--============================================================================
	V_STEP := 800;
	V_STEP_DESC := 'Inserting new relations to D_TABLE_RELATION';
	--============================================================================
	
	INSERT INTO D_TABLE_RELATION (TABLE_RELATION_TK  
		, ORDER_NB
		, SUBJECT_AREA
		, TABLE_TK_A
		, TABLE_COLUMN_TK_A
		, TABLE_TK_B
		, TABLE_COLUMN_TK_B
		, RELATION_TYPE
		, RELATION_LEVEL
		, DELETE_FLAG
		, DM_INSERT_TIMESTAMP
	)
	SELECT NEXT VALUE FOR D_TABLE_RELATION_SEQ AS TABLE_RELATION_TK  
	, T.ORDER_NB
	, TA.SUBJECT_AREA
	, T.TABLE_TK_A
	, T.TABLE_COLUMN_TK_A
	, T.TABLE_TK_B
	, T.TABLE_COLUMN_TK_B
	, T.RELATION_TYPE
	, T.RELATION_LEVEL
	, 'N' AS DELETE_FLAG
	, CURRENT_TIMESTAMP AS DM_INSERT_TIMESTAMP
	FROM TMP_TABLE_RELATION T
	JOIN D_TABLE TA ON T.TABLE_TK_A = TA.TABLE_TK
	LEFT JOIN D_TABLE_RELATION F ON T.TABLE_TK_A = F.TABLE_TK_A
		AND T.TABLE_TK_B = F.TABLE_TK_B
		AND T.RELATION_TYPE = F.RELATION_TYPE
		AND T.ORDER_NB = F.ORDER_NB
		AND F.DELETE_FLAG = 'N'
	WHERE F.TABLE_TK_A IS NULL
	;
	
	V_ROW_COUNT :=  ROW_COUNT;
	RAISE NOTICE 'Step: % (%); Inserted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT;
	--============================================================================
	V_STEP := 900;
	V_STEP_DESC := 'Setting DELETE_FLAG in D_TABLE_RELATION to ''Y'' for relations that no longer exist';
	--============================================================================
	
	UPDATE D_TABLE_RELATION F
		SET DELETE_FLAG = 'Y'
		, DM_UPDATE_TIMESTAMP = CURRENT_TIMESTAMP
	FROM D_TABLE A, D_TABLE B
	WHERE A.TABLE_TK = F.TABLE_TK_A
		AND A.TECHNICAL_AREA = 'Data Vault'
		AND B.TABLE_TK = F.TABLE_TK_B
		AND B.TECHNICAL_AREA = 'Data Vault'
		AND F.DELETE_FLAG = 'N'
		AND (F.TABLE_TK_A, F.TABLE_TK_B, F.ORDER_NB, F.RELATION_TYPE) NOT IN 
			(
			SELECT TABLE_TK_A, TABLE_TK_B, ORDER_NB, RELATION_TYPE
			FROM TMP_TABLE_RELATION
			)
	;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Updated records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	--============================================================================
	-- Final settings
	--============================================================================

RETURN '1';

EXCEPTION
WHEN OTHERS THEN
  V_SQL_ERROR := SQLERRM;
  V_MSGTEXT := 'Step: ' || V_STEP || ' (' || V_STEP_DESC || ')';
  RAISE NOTICE 'Screen run exception: %; Sql error: %' ,V_MSGTEXT, V_SQL_ERROR;
  DROP TABLE TEMP_DV_TABLE_COLUMN IF EXISTS;
	
  RETURN '0, ' || V_MSGTEXT || '; ' || V_SQL_ERROR;
  
END;
END_PROC;
