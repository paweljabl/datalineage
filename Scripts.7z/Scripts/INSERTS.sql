INSERT INTO D_SCREEN_CATEGORY (SCREEN_CATEGORY_TK
       , SCREEN_CATAGORY
       , SCREEN_TYPE
       , SCREEN_NAME
       , SCREEN_DEFINITION
       , SCREEN_SQL_TYPE
       , SCREEN_GENERIC_SQL
) VALUES (NEXT VALUE FOR D_SCREEN_CATEGORY_SEQ
	, 'Column screen'
	, 'Uniqueness'
	, 'Duplicate primary key'
	, 'Checking duplicate keys that should be unique across table'
	, 'SQL Select'
	, NULL
);




 