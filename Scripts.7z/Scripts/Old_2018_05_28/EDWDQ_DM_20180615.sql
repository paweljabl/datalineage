--==============================================================
-- DBMS name:      Netezza 7.0 - Volvo
-- Created on:     2018-06-04 16:13:51
--==============================================================


drop table D_DATE;

drop table D_JOB;

drop table D_SCREEN;

drop table D_SCREEN_CATEGORY;

drop table D_TABLE;

drop table F_JOB_SCREEN_RUN;

drop table F_SCREEN_EVENTS;

drop table L_JOB_RUN_ERRORS;

drop table H_JOB_SCREEN;

drop table H_SOLUTION_BI_JOB;

--==============================================================
-- Table: D_DATE
--==============================================================
create table D_DATE (
   DATE_TK              BIGINT                         not null,
   DATE                 DATE                           null,
   FULL_DATE_UK         CHARACTER(10)                  null,
   FULL_DATE_USA        CHARACTER(10)                  null,
   DAY_OF_MONTH         CHARACTER VARYING(2)           null,
   DAY_SUFFIX           CHARACTER VARYING(4)           null,
   DAY_NAME             CHARACTER VARYING(9)           null,
   DAY_OF_WEEK_USA      CHARACTER(1)                   null,
   DAY_OF_WEEK_UK       CHARACTER(1)                   null,
   DAY_OF_WEEK_IN_MONTH CHARACTER VARYING(2)           null,
   DAY_OF_WEEK_IN_YEAR  CHARACTER VARYING(2)           null,
   DAY_OF_QUARTER       CHARACTER VARYING(3)           null,
   DAY_OF_YEAR          CHARACTER VARYING(3)           null,
   WEEK_OF_MONTH        CHARACTER VARYING(1)           null,
   WEEK_OF_QUARTER      CHARACTER VARYING(2)           null,
   WEEK_OF_YEAR         CHARACTER VARYING(2)           null,
   MONTH                CHARACTER VARYING(2)           null,
   MONTH_NAME           CHARACTER VARYING(9)           null,
   MONTH_OF_QUARTER     CHARACTER VARYING(2)           null,
   QUARTER              CHARACTER(1)                   null,
   QUARTER_NAME         CHARACTER VARYING(9)           null,
   YEAR                 CHARACTER(4)                   null,
   YEAR_NAME            CHARACTER(7)                   null,
   MONTH_YEAR           CHARACTER(10)                  null,
   MMYYYY               CHARACTER(6)                   null,
   FIRST_DAY_OF_MONTH   DATE                           null,
   LAST_DAY_OF_MONTH    DATE                           null,
   FIRST_DAY_OF_QUARTER DATE                           null,
   LAST_DAY_OF_QUARTER  DATE                           null,
   FIRST_DAY_OF_YEAR    DATE                           null,
   LAST_DAY_OF_YEAR     DATE                           null,
   IS_WEEK_DAY          CHARACTER(1)                   null,
   DM_INSERT_TIMESTAMP  TIMESTAMP                      not null,
   constraint PK_D_DATE primary key (DATE_TK)
);

comment on table D_DATE is
'Generic date dimension';

comment on column D_DATE.FULL_DATE_UK is
'dd-MM-yyyy format';

comment on column D_DATE.FULL_DATE_USA is
'Date in MM-dd-yyyy format';

comment on column D_DATE.DAY_OF_MONTH is
'Field will hold day number of Month';

comment on column D_DATE.DAY_SUFFIX is
'Apply suffix as 1st, 2nd ,3rd etc';

comment on column D_DATE.DAY_NAME is
'Contains name of the day, Sunday, Monday';

comment on column D_DATE.DAY_OF_WEEK_USA is
'First Day Sunday=1 and Saturday=7';

comment on column D_DATE.DAY_OF_WEEK_UK is
'First Day Monday=1 and Sunday=7';

comment on column D_DATE.DAY_OF_WEEK_IN_MONTH is
'1st Monday or 2nd Monday in Month';

comment on column D_DATE.WEEK_OF_MONTH is
'Week Number of Month ';

comment on column D_DATE.WEEK_OF_QUARTER is
'Week Number of the Quarter';

comment on column D_DATE.WEEK_OF_YEAR is
'Week Number of the Year';

comment on column D_DATE.MONTH is
'Number of the Month 1 to 12';

comment on column D_DATE.MONTH_NAME is
'January, February etc';

comment on column D_DATE.MONTH_OF_QUARTER is
'Month Number belongs to Quarter';

comment on column D_DATE.QUARTER_NAME is
'First,Second..';

comment on column D_DATE.YEAR is
'Year value of Date stored in Row';

comment on column D_DATE.YEAR_NAME is
'CY 2012,CY 2013';

comment on column D_DATE.MONTH_YEAR is
'Jan-2013,Feb-2013';

comment on column D_DATE.IS_WEEK_DAY is
'0=Week End ,1=Week Day';

comment on column D_DATE.DM_INSERT_TIMESTAMP is
'Record Insertion time';

--==============================================================
-- Table: D_JOB
--==============================================================
create table D_JOB (
   JOB_TK               BIGINT                         not null,
   JOB_NAME             CHARACTER VARYING(50)
                                not null,
   JOB_DESCRIPTION      CHARACTER VARYING(255)
                               null,
   NOTIFICATION_EMAIL_NO_ISSUES CHARACTER VARYING(255)
                                       null,
   NOTIFICATION_EMAIL_ISSUES CHARACTER VARYING(255)
                                    null,
   DM_INSERT_TIMESTAMP  TIMESTAMP                      not null,
   constraint PK_D_JOB primary key (JOB_TK)
)
distribute on random;

comment on table D_JOB is
'Configuration table, storing job specifc parameters, description , meaningful code, notification email etc.
It''s needed to server as for grouping of screens that need to be executed within one job';

comment on column D_JOB.JOB_TK is
'Pirmary key - surrogate key; 
';

comment on column D_JOB.JOB_NAME is
'Short name that would be meaningful , and would resemble screens executed wihin the job';

comment on column D_JOB.JOB_DESCRIPTION is
'Long description of the job purpose and contents.';

comment on column D_JOB.NOTIFICATION_EMAIL_NO_ISSUES is
'Notification email that would serve to send email regardless whether there were any issues reported';

comment on column D_JOB.NOTIFICATION_EMAIL_ISSUES is
'Notification email that would serve to send email with the result of the job if some screens returns data quality issues.';

comment on column D_JOB.DM_INSERT_TIMESTAMP is
'Record Insertion time';

--==============================================================
-- Table: D_SCREEN
--==============================================================
create table D_SCREEN (
   SCREEN_TK            BIGINT                         not null,
   SCREEN_CATEGORY_TK   BIGINT                         null,
   TABLE_TK             BIGINT                         null,
   SCREEN_DESCRIPTION   CHARACTER VARYING(255)         null,
   SCREEN_SPECIFIC_SQL  NATIONAL CHARACTER VARYING(2000) null,
   NR_OF_EVENTS_2_RECORD BIGINT                         null,
   TOTAL_RECORDS_QT_SQL NATIONAL CHARACTER VARYING(2000) null,
   SAVE_GOOD_RUN_TOTAL_COUNT CHARACTER(1)              null,
   ACTIVE               CHARACTER(1)                   null,
   DM_INSERT_TIMESTAMP  TIMESTAMP                      not null,

   constraint PK_D_SCREEN primary key (SCREEN_TK)
);

comment on table D_SCREEN is
'Configuration table storing screen definition.';

comment on column D_SCREEN.SCREEN_TK is
'Pirmary key - surrogate key';

comment on column D_SCREEN.SCREEN_CATEGORY_TK is
'The foreign key to D_SCREEN_CATEGORY';

comment on column D_SCREEN.TABLE_TK is
'The foreign key to table (D_TABLE) for which the screen is applied; 
by definition a screen can be applied on one table at the time;
so multiple entries should be created, one for each table, for the same screen applied on different table.
If a given screen would record an incident - and records from multiple tables make up an incident,
they would be recorded in F_DQ_EVENT_DETAILS table, as data set causing an issue , 
but that incident is reported for the table defined by this field (TABLE_KEY)';

comment on column D_SCREEN.SCREEN_DESCRIPTION is
'Field used to describe screen, providing more details than present in screen category table; for example for uniqueness screen it can provide unique criteria';

comment on column D_SCREEN.SCREEN_SPECIFIC_SQL is
'Field captures the view, actual snippet of SQL or procedural SQL 
used to execute the data-quality check. It''s only populated when SCREEN_GENERIC_VIEW_OR_SQL is not applicable';

comment on column D_SCREEN.NR_OF_EVENTS_2_RECORD is
'Maximum number of screen vialations events that will be written to F_SCREEN_EVENTS; if NULL all captured vialations will be recorded';

comment on column D_SCREEN.TOTAL_RECORDS_QT_SQL is
'Sql text to be executed to capture the total number of records applicable for the screen scope (usually a table) 
- needed if we want to measure number of good vs bad records';

comment on column D_SCREEN.ACTIVE is
'The flag used by the application to run a check or not; for example for Deleted columns or tables check should be disabled; 
and if check for some problematic columns might be disabled';

comment on column D_SCREEN.DM_INSERT_TIMESTAMP is
'Record Insertion time';

comment on column D_SCREEN.SAVE_GOOD_RUN_TOTAL_COUNT is
'Y/N flag saying whether good screen runs should execute and save query result for TOTAL_RECORDS_QT in F_JOB_SCREEN_RUN; by default it''s only recorded for violations';


--==============================================================
-- Table: D_SCREEN_CATEGORY
--==============================================================
create table D_SCREEN_CATEGORY (
   SCREEN_CATEGORY_TK   BIGINT                         not null,
   SCREEN_CATAGORY      CHARACTER VARYING(50)          not null,
   SCREEN_TYPE          CHARACTER VARYING(50)          not null,
   SCREEN_NAME          CHARACTER VARYING(100)         null,
   SCREEN_DEFINITION    NATIONAL CHARACTER VARYING(255) null,
   SCREEN_SQL_TYPE      CHARACTER VARYING(50)          null,
   SCREEN_GENERIC_SQL   NATIONAL CHARACTER VARYING(2000) null,
   DM_INSERT_TIMESTAMP  TIMESTAMP                      null,
   constraint PK_D_SCREEN_CATEGORY primary key (SCREEN_CATEGORY_TK)
)
distribute on random;

comment on table D_SCREEN_CATEGORY is
'Configuration table storing screen categories, types and generic definition.';

comment on column D_SCREEN_CATEGORY.SCREEN_CATEGORY_TK is
'Pirmary key - surrogate key';

comment on column D_SCREEN_CATEGORY.SCREEN_CATAGORY is
'3 categories: column screens, structure screens, and business rule screens. 
Column screens test the data within a single column. These are usually simple,
somewhat obvious tests, such as testing whether a column contains unexpected
null values, if a value falls outside of a prescribed range, or if a value fails to adhere
to a required format.
Structure screens test the relationship of data across columns. Two or more
attributes may be tested to verify they implement a hierarchy, such as a series of
many-to-one relationships. Structure screens also test foreign key/primary key relationships
between columns in two tables, and also include testing whole blocks of
columns to verify they implement valid postal addresses.
Business rule screens implement more complex tests that do not fit the simpler
column or structure screen categories. For example, whether source load , VDA, 
has been completely loaded or there are some gaps.  Business rule screens also include 
aggregate threshold data quality checks, such as checking to see if number of new loaded records
is very low, below expected threshold. In this case, the screen throws an error only after a threshold 
is not reached.';

comment on column D_SCREEN_CATEGORY.SCREEN_TYPE is
'It''s used to group data-quality screens related by theme, such as Completeness or Validation or Out-of-Bounds, Duplicate Key etc';

comment on column D_SCREEN_CATEGORY.SCREEN_NAME is
'Human identifier of the screen , for example: Duplicate_Current_Y_Flag_D_VEHICLE ';

comment on column D_SCREEN_CATEGORY.SCREEN_DEFINITION is
'Field defines what the screen should do / check - human explanation';

comment on column D_SCREEN_CATEGORY.SCREEN_SQL_TYPE is
'Informes whether check is applied via view, SQL snippet, or procedure; helps to interpret SCREEN_GENERIC_SQL';

comment on column D_SCREEN_CATEGORY.SCREEN_GENERIC_SQL is
'Field captures the view, actual snippet of SQL or procedural SQL 
used to execute the data-quality check. If applicable,  this SQL should return the set of unique identifiers for the rows that
violate the data-quality screen so that this can be used to insert new records into F_SCREEN_EVENTS';

comment on column D_SCREEN_CATEGORY.DM_INSERT_TIMESTAMP is
'Record Insertion time';


drop table D_TABLE IF EXISTS;

--==============================================================
-- Table: D_TABLE
--==============================================================
create table D_TABLE (
   TABLE_TK             BIGINT                         not null,
   NAME                 CHARACTER VARYING(255)         null,
   SUBJECT_AREA         CHARACTER VARYING(50)          null,
   TECHNICAL_AREA       CHARACTER VARYING(50)          null,
   DATABASE_NAME        CHARACTER VARYING(50)          null,
   OBJECT_TYPE          CHARACTER VARYING(20)          null,
   OBJECT_TYPE_CODE     CHARACTER VARYING(20)          null,
   DM_INSERT_TIMESTAMP  TIMESTAMP                      not null,
   constraint PK_D_TABLE primary key (TABLE_TK)
);

comment on table D_TABLE is
'Dimension listing EDW tables; There needs to be one ''N/A'' record added for screens not applicable on table / view level.';

comment on column D_TABLE.TABLE_TK is
'Pirmary key - surrogate key
';

comment on column D_TABLE.NAME is
'Name of the view or table';

comment on column D_TABLE.SUBJECT_AREA is
'Field defines Source System, for example VDA, CTDI etc, or Data Mart area for example PARTS etc
';

comment on column D_TABLE.TECHNICAL_AREA is
'Field defines whether screen is applied within Data Vault, Data Mart, Staging database area';

comment on column D_TABLE.DATABASE_NAME is
'Database name, with real environment prefix, for example PROD_PARTS_DM, PROD_EDW_STOV;
Potentially the checks might be applied on QA env, but on PROD copied data.';

comment on column D_TABLE.OBJECT_TYPE is
'Satellite, Hub, Link, Dimension etc';

comment on column D_TABLE.OBJECT_TYPE_CODE is
'SAT, HUB, LNK, DIM etc';

comment on column D_TABLE.DM_INSERT_TIMESTAMP is
'Record Insertion time';

--==============================================================
-- Table: F_JOB_SCREEN_RUN
--==============================================================
create table F_JOB_SCREEN_RUN (
   JOB_SCREEN_RUN_TK    BIGINT                         not null,
   SCREEN_TK            BIGINT                         not null,
   JOB_TK               BIGINT                         null,
   DM_CURRENT           CHARACTER(1)                   null,
   SCREEN_RUN_START_DATE_TK BIGINT                         not null,
   SCREEN_RUN_START_TIMESTAMP TIMESTAMP                      null,
   SCREEN_RUN_TIME_SECONDS BIGINT                         null,
   SCREEN_RESULT        CHARACTER VARYING(255)         null,
   VIOLATED_RECORDS_QT  BIGINT                         null,
   TOTAL_RECORDS_QT     BIGINT                         null,
   constraint PK_F_JOB_SCREEN_RUN primary key (JOB_SCREEN_RUN_TK)
)
distribute on random;

comment on table F_JOB_SCREEN_RUN is
'Each row in this table correspondes to a screen run, giving details such as screen run result and total number of error records.';

comment on column F_JOB_SCREEN_RUN.JOB_SCREEN_RUN_TK is
'Surrogate key - unique value per each screen  run';

comment on column F_JOB_SCREEN_RUN.SCREEN_TK is
'Foreign key to D_SCREEN table';

comment on column F_JOB_SCREEN_RUN.JOB_TK is
'Foreign key to D_JOB table';

comment on column F_JOB_SCREEN_RUN.DM_CURRENT is
'Y/N, to find out the most recent run';

comment on column F_JOB_SCREEN_RUN.SCREEN_RUN_START_DATE_TK is
'Foreign key to D_DATE; date of the screen run';

comment on column F_JOB_SCREEN_RUN.SCREEN_RUN_START_TIMESTAMP is
'Timestamp of the screen run';

comment on column F_JOB_SCREEN_RUN.SCREEN_RUN_TIME_SECONDS is
'Total run time in seconds';

comment on column F_JOB_SCREEN_RUN.SCREEN_RESULT is
'Vialoted , or some other description of the screen result';

comment on column F_JOB_SCREEN_RUN.VIOLATED_RECORDS_QT is
'Count of the records in F_SCREEN_EVENTS corresponding to a given screen run';

comment on column F_JOB_SCREEN_RUN.TOTAL_RECORDS_QT is
'total number of records from the table for which screen is run; can be useful to see ratio of good records';

drop table F_SCREEN_EVENTS if exists;
--==============================================================
-- Table: F_SCREEN_EVENTS
--==============================================================
create table F_SCREEN_EVENTS (
   JOB_SCREEN_RUN_TK    BIGINT                         not null,
   SCREEN_TK            BIGINT                         not null,
   TABLE_TK             BIGINT                         not null,
   TABLE_ROWID          BIGINT                         not null,
   SCREEN_EVENT_NB      BIGINT                         not null,
   SCREEN_RUN_DATE_TK   BIGINT                         null,
   SCREEN_RUN_TIME      TIMESTAMP                      null,
   FIELD_NAME           CHARACTER VARYING(255)         null,
   SCREEN_VIOLATION_CONDITION NATIONAL CHARACTER VARYING(500) null,
   constraint PK_F_SCREEN_EVENTS primary key (TABLE_ROWID, SCREEN_TK, TABLE_TK, JOB_SCREEN_RUN_TK)
)
distribute on random;

comment on table F_SCREEN_EVENTS is
'Each data-quality vialation within a single screen is captured as a row in the event fact table. One screen can return as many records as there a table records for table / column screens. Sometimes one error is reflected by 2, 3 or more records for complex structure or business rule screen, where a single event generates many rows in this error event  fact table. Thus, SCREEN_EVENT# helps to group records accountable for one screen event. Most of the time however it will be one record per registered error, for example one record for each NULL record in specific column.';

comment on column F_SCREEN_EVENTS.JOB_SCREEN_RUN_TK is
'Foreign key to F_JOB_RUN';

comment on column F_SCREEN_EVENTS.SCREEN_TK is
'Foreign key to D_SCREEN table';

comment on column F_SCREEN_EVENTS.TABLE_TK is
'Foreign key to D_TABLE for each table that participated in / caused screen violation';

comment on column F_SCREEN_EVENTS.TABLE_ROWID is
'ROWID  of the table that participated in screen violation';

comment on column F_SCREEN_EVENTS.SCREEN_EVENT_NB is
'It''s needed to server as grouping field for each screen violation case - there can be 10 vialations for one screen,
but number of returned records by the screen is 20 since 2 fields or tables make up for one vialation.';

comment on column F_SCREEN_EVENTS.SCREEN_RUN_DATE_TK is
'Foreign key to D_DATE; date when screen event is recorded';

comment on column F_SCREEN_EVENTS.SCREEN_RUN_TIME is
'Time when record is added to the ';

comment on column F_SCREEN_EVENTS.FIELD_NAME is
'Each fields that participated in / caused screen violation';

comment on column F_SCREEN_EVENTS.SCREEN_VIOLATION_CONDITION is
'Description of the given screen run - free text . optionaly added to describe the given screen violation run';

--==============================================================
-- Table: L_JOB_RUN_ERRORS
--==============================================================
create table L_JOB_RUN_ERRORS (
   SCREEN_RUN_TIMESTAMP TIMESTAMP                      not null,
   SCREEN_TK            BIGINT                         not null,
   JOB_TK               BIGINT                         not null,
   SQL_ERROR            CHARACTER VARYING(2000)        null,
   constraint PK_L_JOB_RUN_ERRORS primary key (SCREEN_TK, JOB_TK, SCREEN_RUN_TIMESTAMP)
)
distribute on random;

comment on table L_JOB_RUN_ERRORS is
'Log table informing about failed screen runs from within job execution;';

comment on column L_JOB_RUN_ERRORS.SCREEN_RUN_TIMESTAMP is
'Timestamp of the screen run';

comment on column L_JOB_RUN_ERRORS.SCREEN_TK is
'Foreign key to D_SCREEN table';

comment on column L_JOB_RUN_ERRORS.JOB_TK is
'Foreign key to D_JOB table';


comment on column L_JOB_RUN_ERRORS.SQL_ERROR is
'Error returned by failed screen execution';

--==============================================================
-- Table: H_JOB_SCREEN
--==============================================================
create table H_JOB_SCREEN (
   JOB_SCREEN_TK        BIGINT                         not null,
   JOB_TK               BIGINT                         null,
   SCREEN_TK            BIGINT                         null,
   PROCESSING_ORDER_NB  BIGINT                         null,
   DM_INSERT_TIMESTAMP  TIMESTAMP                      not null,
   constraint PK_H_JOB_SCREEN primary key (JOB_SCREEN_TK)
)
distribute on random;

comment on table H_JOB_SCREEN is
' Configuration table storing screens that should be performed within one execution of the job.';

comment on column H_JOB_SCREEN.JOB_SCREEN_TK is
'Primary key - surrogate key';

comment on column H_JOB_SCREEN.JOB_TK is
'The key to D_JOB';

comment on column H_JOB_SCREEN.SCREEN_TK is
'The key to D_SCREEN';

comment on column H_JOB_SCREEN.PROCESSING_ORDER_NB is
'It''s a primitive scheduling/dependency device, informing the overall ETL master process of the order 
in which to run the screens. Data-quality screens with the same processing-order number can be run in parallel.';

comment on column H_JOB_SCREEN.DM_INSERT_TIMESTAMP is
'Record Insertion time';

--==============================================================
-- Table: H_SOLUTION_BI_JOB
--==============================================================
create table H_SOLUTION_BI_JOB (
   JOB_TK               BIGINT                         not null,
   SOLUTION_ID          INTEGER                        null,
   DM_INSERT_TIMESTAMP  TIMESTAMP                      not null,
   constraint PK_H_SOLUTION_BI_JOB primary key (JOB_TK)
)
distribute on random;

comment on table H_SOLUTION_BI_JOB is
'Table linking JOBs with BI Solution from MONITORING_DM.BI_SOLUTIONS ';

comment on column H_SOLUTION_BI_JOB.JOB_TK is
'Foreign key to D_JOB
';

comment on column H_SOLUTION_BI_JOB.SOLUTION_ID is
'Foreign key to D_BI_SOLUTION';

comment on column H_SOLUTION_BI_JOB.DM_INSERT_TIMESTAMP is
'Record Insertion time';

drop table D_TABLE_COLUMN_DV IF EXISTS;

--==============================================================
-- Table: D_TABLE_COLUMN_DV
--==============================================================
create table D_TABLE_COLUMN_DV (
   TABLE_COLUMN_DV_TK   BIGINT                         not null,
   TABLE_TK             BIGINT                         null,
   TABLE_TYPE           CHARACTER VARYING(64)          null,
   TABLE_NAME           CHARACTER VARYING(64)          null,
   TABLE_ACTIVE         CHARACTER VARYING(1)           null,
   SUBJECT_AREA         CHARACTER VARYING(64)          null,
   OBJ_KEY              INTEGER                        null,
   COL_KEY              INTEGER                        null,
   COL_NAME             CHARACTER VARYING(64)          null,
   DISPLAY_NAME         CHARACTER VARYING(256)         null,
   DATA_TYPE            CHARACTER VARYING(256)         null,
   NULLS_FLAG           CHARACTER VARYING(1)           null,
   NUMERIC_FLAG         CHARACTER VARYING(1)           null,
   ADDITIVE_FLAG        CHARACTER VARYING(1)           null,
   ATTRIBUTE_FLAG       CHARACTER VARYING(1)           null,
   COL_FORMAT           CHARACTER VARYING(64)          null,
   SRC_TABLE            CHARACTER VARYING(64)          null,
   SRC_COLUMN           CHARACTER VARYING(64)          null,
   COL_ORDER            INTEGER                        null,
   KEY_TYPE             CHARACTER VARYING(1)           null,
   JOIN_FLAG            CHARACTER VARYING(1)           null,
   BUSINESS_KEY_IND     CHARACTER VARYING(1)           null,
   PRIMARY_INDEX_IND    CHARACTER VARYING(1)           null,
   DEFAULT_VALUE        CHARACTER VARYING(1024)        null,
   CASE_FLAG            CHARACTER VARYING(1)           null,
   TITLE                CHARACTER VARYING(64)          null,
   COMPRESS_FLAG        CHARACTER VARYING(1)           null,
   COMMENTS             CHARACTER VARYING(256)         null,
   COL_TYPE             CHARACTER VARYING(64)          null,
   UPDATE_FLAG          CHARACTER VARYING(1)           null,
   DISPLAY_TYPE         CHARACTER VARYING(64)          null,
   PRE_JOIN_SOURCE      CHARACTER VARYING(64)          null,
   IND_1                CHARACTER VARYING(1)           null,
   DM_INSERT_TIMESTAMP  TIMESTAMP                      not null,
   constraint PK_D_TABLE_COLUMN_DV primary key (TABLE_COLUMN_DV_TK)
);

comment on table D_TABLE_COLUMN_DV is
'Table storing Wherescape Metadata';

comment on column D_TABLE_COLUMN_DV.TABLE_COLUMN_DV_TK is
'Pirmary key - surrogate key';

comment on column D_TABLE_COLUMN_DV.TABLE_TK is
'Foreign key 2 D_TABLE
';

drop table F_TABLE_RELATIONS IF EXISTS;

--==============================================================
-- Table: F_TABLE_RELATIONS
--==============================================================
create table F_TABLE_RELATIONS (
   TABLE_TK_A           BIGINT                         null,
   TABLE_TK_B           BIGINT                         null,
   RELATION_TYPE        CHARACTER VARYING(64)          null,
   RELATION_LEVEL       BIGINT                         null,
   DM_INSERT_TIMESTAMP  TIMESTAMP                      not null
);

comment on table F_TABLE_RELATIONS is
'Table storing relations between tables, like Table A is a source for Table B';

comment on column F_TABLE_RELATIONS.TABLE_TK_A is
'Foreign key to D_TABLE -  table A of a relation (beginning)
';

comment on column F_TABLE_RELATIONS.TABLE_TK_B is
'Foreign key to D_TABLE -  table B of a relation (end)';

comment on column F_TABLE_RELATIONS.RELATION_TYPE is
'Name of the relation, for example: IS_SOURCE_TO';

comment on column F_TABLE_RELATIONS.RELATION_LEVEL is
'1 for direct connection; 2 for indirect relation there''s some proxy table in between - 3 if there are two proxy relations inbetween etc';

comment on column F_TABLE_RELATIONS.DM_INSERT_TIMESTAMP is
'Record Insertion time';

alter table F_TABLE_RELATIONS add constraint FK_TABLE_RELATIONS_A_2_TABLE foreign key (TABLE_TK_A)
   references D_TABLE (TABLE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_TABLE_RELATIONS add constraint FK_TABLE_RELATIONS_B_2_TABLE foreign key (TABLE_TK_B)
   references D_TABLE (TABLE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table D_TABLE_COLUMN_DV add constraint FK_TABLE_COLUMN_DV_2_TABLE foreign key (TABLE_TK)
   references D_TABLE (TABLE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table D_SCREEN add constraint FK_SCREEN_2_TABLE foreign key (TABLE_TK)
   references D_TABLE (TABLE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table D_SCREEN add constraint FK_SCREEN_CATEGORY_2_SCREEN foreign key (SCREEN_CATEGORY_TK)
   references D_SCREEN_CATEGORY (SCREEN_CATEGORY_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_JOB_SCREEN_RUN add constraint FK_JOB_SCREEN_RUN_2_JOB foreign key (JOB_TK)
   references D_JOB (JOB_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_JOB_SCREEN_RUN add constraint FK_SCREEN_RUN_2_DATE foreign key (SCREEN_RUN_START_DATE_TK)
   references D_DATE (DATE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_JOB_SCREEN_RUN add constraint FK_SCREEN_RUN_2_SCREEN foreign key (SCREEN_TK)
   references D_SCREEN (SCREEN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_DATE foreign key (SCREEN_RUN_DATE_TK)
   references D_DATE (DATE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_SCREEN foreign key (SCREEN_TK)
   references D_SCREEN (SCREEN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_SCREEN_RUN foreign key (JOB_SCREEN_RUN_TK)
   references F_JOB_SCREEN_RUN (JOB_SCREEN_RUN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table F_SCREEN_EVENTS add constraint FK_SCREEN_EVENTS_2_TABLE foreign key (TABLE_TK)
   references D_TABLE (TABLE_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table L_JOB_RUN_ERRORS add constraint FK_JOB_RUN_ERROR_2_JOB foreign key (JOB_TK)
   references D_JOB (JOB_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table L_JOB_RUN_ERRORS add constraint FK_JOB_RUN_ERROR_2_SCREEN foreign key (SCREEN_TK)
   references D_SCREEN (SCREEN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table H_JOB_SCREEN add constraint FK_JOB_SCREEN_2_JOB foreign key (JOB_TK)
   references D_JOB (JOB_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table H_JOB_SCREEN add constraint FK_JOB_SCREEN_2_SCREEN foreign key (SCREEN_TK)
   references D_SCREEN (SCREEN_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

alter table H_SOLUTION_BI_JOB add constraint FK_SOLUTION_BI_JOB_D_JOB foreign key (JOB_TK)
   references D_JOB (JOB_TK)
   match full
   on update restrict
   on delete restrict
   not deferrable;

CALL PROC_DELETE_SEQUENCE('D_JOB_SEQ');
CREATE SEQUENCE D_JOB_SEQ AS BIGINT
	START WITH 1
	INCREMENT BY 1
	NO MINVALUE 
	NO MAXVALUE 
	NO CYCLE;

CALL PROC_DELETE_SEQUENCE('H_JOB_SCREEN_SEQ');
CREATE SEQUENCE H_JOB_SCREEN_SEQ AS BIGINT
	START WITH 1
	INCREMENT BY 1
	NO MINVALUE 
	NO MAXVALUE 
	NO CYCLE;

CALL PROC_DELETE_SEQUENCE('D_SCREEN_SEQ');
CREATE SEQUENCE D_SCREEN_SEQ AS BIGINT
	START WITH 1
	INCREMENT BY 1
	NO MINVALUE 
	NO MAXVALUE 
	NO CYCLE;

CALL PROC_DELETE_SEQUENCE('D_SCREEN_CATEGORY_SEQ');
CREATE SEQUENCE D_SCREEN_CATEGORY_SEQ AS BIGINT
	START WITH 1
	INCREMENT BY 1
	NO MINVALUE 
	NO MAXVALUE 
	NO CYCLE;

CALL PROC_DELETE_SEQUENCE('D_TABLE_SEQ');
CREATE SEQUENCE D_TABLE_SEQ AS BIGINT
	START WITH 1
	INCREMENT BY 1
	NO MINVALUE 
	NO MAXVALUE 
	NO CYCLE;

CALL PROC_DELETE_SEQUENCE('F_JOB_SCREEN_RUN_SEQ'); 
CREATE SEQUENCE F_JOB_SCREEN_RUN_SEQ AS BIGINT
	START WITH 1
	INCREMENT BY 1
	NO MINVALUE 
	NO MAXVALUE 
	NO CYCLE;
	
CALL PROC_DELETE_SEQUENCE('D_TABLE_COLUMN_DV_SEQ'); 
CREATE SEQUENCE D_TABLE_COLUMN_DV_SEQ AS BIGINT
	START WITH 1
	INCREMENT BY 1
	NO MINVALUE 
	NO MAXVALUE 
	NO CYCLE;
