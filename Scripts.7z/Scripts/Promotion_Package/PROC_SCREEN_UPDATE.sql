CREATE OR REPLACE PROCEDURE PROC_SCREEN_UPDATE (VARARGS)
RETURNS CHARACTER VARYING(ANY)
LANGUAGE NZPLSQL 
AS
BEGIN_PROC
DECLARE

	--============================================================================
	-- Input variables
	--============================================================================
	
	P_SCREEN_CATEGORY_CODE ALIAS FOR $1;
--	P_INPUT_VARIABLE_2 ALIAS FOR $2;

	--============================================================================
	-- Control variables used in most procedures
	--============================================================================

	V_MSGTEXT           VARCHAR(2000);  -- Text for audit_trail
	V_SQL               VARCHAR(4000);  -- Text for SQL statements
	V_STEP              INTEGER;       -- Indicator which part of the code was last executed when proc execution failed
	V_STEP_DESC			VARCHAR(255);  -- Description of the step (part of the code)
	V_INSERT_COUNT      BIGINT;        -- No of records inserted
	V_COUNT             BIGINT;        -- General counter
	V_ROW_COUNT			BIGINT;        -- General row count
	V_SQL_ERROR         VARCHAR(2000);  -- Sql error code for audit trail as varchar
	
	--============================================================================
	-- Procedure variables
	--============================================================================
	V_START_TIME TIMESTAMP;
	
BEGIN	
	
	--============================================================================
	V_STEP := 100;
	V_STEP_DESC := 'Initial variables setup / temp table creation with new / changed screens';
	--============================================================================
	
	V_START_TIME := CURRENT_TIMESTAMP;
	
	CREATE TEMP TABLE TEMP_SCREEN_NEW AS 
	SELECT * FROM TEMP_SCREEN
	MINUS 
	SELECT S.SCREEN_CODE, S.SCREEN_CATEGORY_TK, S.TABLE_TK, S.TABLE_COLUMN_TK, S.SCREEN_DESCRIPTION, S.SCREEN_SPECIFIC_SQL, S.TOTAL_RECORDS_QT_SQL, S.ENVIRONMENT
	FROM D_SCREEN S
	WHERE S.SCREEN_CODE IN (SELECT SCREEN_CODE FROM TEMP_SCREEN)
	;
	
	--============================================================================
	V_STEP := 200;
	V_STEP_DESC := 'Setting DELETE_FLAG in D_SCREEN to ''Y'' for screens with changed screen definition';
	--============================================================================
	
	UPDATE D_SCREEN S
		SET S.DELETE_FLAG = 'Y'
			, S.DM_UPDATE_TIMESTAMP = V_START_TIME
	WHERE S.SCREEN_CODE IN (SELECT SCREEN_CODE FROM TEMP_SCREEN_NEW)
	;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Updated records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	--============================================================================
	V_STEP := 300;
	V_STEP_DESC := 'Inserting new / changed screens to D_SCREEN';
	--============================================================================
	
	INSERT INTO D_SCREEN (SCREEN_TK, SCREEN_CODE, SCREEN_CATEGORY_TK, TABLE_TK, TABLE_COLUMN_TK, SCREEN_DESCRIPTION, SCREEN_SPECIFIC_SQL, NR_OF_EVENTS_2_RECORD, TOTAL_RECORDS_QT_SQL, SAVE_GOOD_RUN_TOTAL_COUNT, ACTIVE, DELETE_FLAG, ENVIRONMENT, DM_INSERT_TIMESTAMP)
	SELECT NEXT VALUE FOR D_SCREEN_SEQ
	, U.SCREEN_CODE
	, U.SCREEN_CATEGORY_TK
	, U.TABLE_TK
	, U.TABLE_COLUMN_TK
	, CASE 
		WHEN LENGTH(U.SCREEN_DESCRIPTION) > 250 THEN SUBSTR(U.SCREEN_DESCRIPTION, 250) || '...' 
		ELSE U.SCREEN_DESCRIPTION END AS SCREEN_DESCRIPTION  
	, U.SCREEN_SPECIFIC_SQL
	, 10 AS NR_OF_EVENTS_2_RECORD
	, U.TOTAL_RECORDS_QT_SQL
	, 'N' AS SAVE_GOOD_RUN_TOTAL_COUNT
	, 'Y' AS ACTIVE
	, 'N' AS DELETE_FLAG
	, U.ENVIRONMENT
	, V_START_TIME AS DM_INSERT_TIMESTAMP
	FROM TEMP_SCREEN_NEW U
	;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: (%); Inserted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	--============================================================================
	V_STEP := 400;
	V_STEP_DESC := 'Setting DELETE_FLAG in D_SCREEN to ''Y'' for screens on tables / columns that no longer exist';
	--============================================================================
	
	UPDATE D_SCREEN S
		SET S.DELETE_FLAG = 'Y'
			, S.DM_UPDATE_TIMESTAMP = V_START_TIME
	WHERE S.SCREEN_CATEGORY_TK = (SELECT SCREEN_CATEGORY_TK FROM D_SCREEN_CATEGORY WHERE SCREEN_CATEGORY_CODE = P_SCREEN_CATEGORY_CODE)
		AND S.DELETE_FLAG = 'N'
		AND S.SCREEN_CODE NOT IN (SELECT SCREEN_CODE FROM TEMP_SCREEN)
	;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Updated records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	--============================================================================
	V_STEP := 500;
	V_STEP_DESC := 'Drop temp tables';
	--============================================================================
	
	DROP TABLE TEMP_SCREEN_NEW IF EXISTS;
	DROP TABLE TEMP_SCREEN IF EXISTS;
	RAISE NOTICE 'Step: % (%)', V_STEP, V_STEP_DESC ;
	
--============================================================================
-- Final settings
--============================================================================

RETURN '1';

EXCEPTION
WHEN OTHERS THEN
  V_SQL_ERROR := SQLERRM;
  V_MSGTEXT := 'Step: ' || V_STEP || ' (' || V_STEP_DESC || ')';
  RAISE NOTICE 'Screen run exception: %; Sql error: %' ,V_MSGTEXT, V_SQL_ERROR;
  DROP TABLE TEMP_SCREEN IF EXISTS;
	
  RETURN '0, ' || V_MSGTEXT || '; ' || V_SQL_ERROR;
  
END;
END_PROC;
