CREATE OR REPLACE PROCEDURE PROC_DV_METADATA_REFRESH()
RETURNS CHARACTER VARYING(ANY)
LANGUAGE NZPLSQL 
AS
BEGIN_PROC
DECLARE

	--============================================================================
	-- Input variables
	--============================================================================
	
--	P_INPUT_VARIABLE_2 ALIAS FOR $2;

	--============================================================================
	-- Control variables used in most procedures
	--============================================================================

	V_MSGTEXT           VARCHAR(2000);  -- Text for audit_trail
	V_SQL               VARCHAR(4000);  -- Text for SQL statements
	V_STEP              INTEGER;       -- Indicator which part of the code was last executed when proc execution failed
	V_STEP_DESC			VARCHAR(255);  -- Description of the step (part of the code)
	V_INSERT_COUNT      BIGINT;        -- No of records inserted
	V_COUNT             BIGINT;        -- General counter
	V_ROW_COUNT			BIGINT;        -- General row count
	V_SQL_ERROR         VARCHAR(2000);  -- Sql error code for audit trail as varchar
	V_RETURN_MSG		VARCHAR(4000);  -- Overall result message
	V_STATUS			INTEGER;       -- Overall result status. 1=okay
	
	--============================================================================
	-- Procedure variables
	--============================================================================
	V_START_TIME		TIMESTAMP;
	V_ENV				VARCHAR(255);
	V_REC 				RECORD;
	
BEGIN	
	
	--============================================================================
	V_STEP := 100;
	V_STEP_DESC := 'Initial variables setup ';
	--============================================================================
	
	V_START_TIME := CURRENT_TIMESTAMP;
	SELECT SUBSTR(CURRENT_CATALOG, 1, INSTR(CURRENT_CATALOG, '_', 1) - 1 ) INTO V_ENV;
	
	--============================================================================
	V_STEP := 200;
	V_STEP_DESC := 'Looping through environements';
	--============================================================================
	
	FOR V_REC IN SELECT E.ENVIRONMENT 
		FROM C_ENVIRONMENT_PER_ENVIRONMENT E
		WHERE E.ENVIRONMENT_HOST = V_ENV LOOP
	BEGIN
		
		V_STEP_DESC := 'Calling PROC_DV_TABLE_REFRESH for ' || V_ENV;
		RAISE NOTICE 'Calling PROC_DV_TABLE_REFRESH for %', V_ENV;
		
		V_RETURN_MSG := PROC_DV_TABLE_REFRESH(V_ENV);
		V_STATUS := SUBSTR(V_RETURN_MSG, 1, 1);
		IF V_STATUS = 0 THEN
			RAISE EXCEPTION '%', V_RETURN_MSG;
		END IF;	
	
		V_STEP_DESC := 'Calling PROC_DV_TABLE_COLUMN_REFRESH for ' || V_ENV;
		RAISE NOTICE 'Calling PROC_DV_TABLE_COLUMN_REFRESH for %', V_ENV;
		
		V_RETURN_MSG := PROC_DV_TABLE_COLUMN_REFRESH(V_ENV);
		V_STATUS := SUBSTR(V_RETURN_MSG, 1, 1);
		IF V_STATUS = 0 THEN
			RAISE EXCEPTION '%', V_RETURN_MSG;
		END IF;	
		
		V_STEP_DESC := 'Calling PROC_DV_TABLE_COLUMN_DV_REFRESH for ' || V_ENV;
		RAISE NOTICE 'Calling PROC_DV_TABLE_COLUMN_DV_REFRESH for %', V_ENV;
		
		V_RETURN_MSG := PROC_DV_TABLE_COLUMN_DV_REFRESH(V_ENV);
		V_STATUS := SUBSTR(V_RETURN_MSG, 1, 1);
		IF V_STATUS = 0 THEN
			RAISE EXCEPTION '%', V_RETURN_MSG;
		END IF;		
	
	END;
	END LOOP;
	
	--============================================================================
	V_STEP := 300;
	V_STEP_DESC := 'Rest of the procedures';
	--============================================================================
	
	V_STEP_DESC := 'Calling PROC_DV_TABLE_RELATION_REFRESH';
	RAISE NOTICE 'Calling PROC_DV_TABLE_RELATION_REFRESH';
	V_RETURN_MSG := PROC_DV_TABLE_RELATION_REFRESH();
	V_STATUS := SUBSTR(V_RETURN_MSG, 1, 1);
	IF V_STATUS = 0 THEN
		RAISE EXCEPTION '%', V_RETURN_MSG;
	END IF;		

	V_STEP_DESC := 'Calling PROC_DV_SCREEN_PK';
	RAISE NOTICE 'Calling PROC_DV_SCREEN_PK';
	V_RETURN_MSG := PROC_DV_SCREEN_PK();
	V_STATUS := SUBSTR(V_RETURN_MSG, 1, 1);
	IF V_STATUS = 0 THEN
		RAISE EXCEPTION '%', V_RETURN_MSG;
	END IF;	
	
	V_STEP_DESC := 'Calling PROC_DV_SCREEN_DV_CUR_F';
	RAISE NOTICE 'Calling PROC_DV_SCREEN_DV_CUR_F';
	V_RETURN_MSG := PROC_DV_SCREEN_DV_CUR_F();
	V_STATUS := SUBSTR(V_RETURN_MSG, 1, 1);
	IF V_STATUS = 0 THEN
		RAISE EXCEPTION '%', V_RETURN_MSG;
	END IF;		
	
	V_STEP_DESC := 'Calling PROC_DV_SCREEN_DV_SID';
	RAISE NOTICE 'Calling PROC_DV_SCREEN_DV_SID';
	V_RETURN_MSG := PROC_DV_SCREEN_DV_SID();
	V_STATUS := SUBSTR(V_RETURN_MSG, 1, 1);
	IF V_STATUS = 0 THEN
		RAISE EXCEPTION '%', V_RETURN_MSG;
	END IF;		
	
	V_STEP_DESC := 'Calling PROC_DV_JOB_REFRESH';
	RAISE NOTICE 'Calling PROC_DV_JOB_REFRESH';
	V_RETURN_MSG := PROC_DV_JOB_REFRESH();
	V_STATUS := SUBSTR(V_RETURN_MSG, 1, 1);
	IF V_STATUS = 0 THEN
		RAISE EXCEPTION '%', V_RETURN_MSG;
	END IF;		

	V_STEP_DESC := 'Calling PROC_DV_JOB_SCREEN_REFRESH';
	RAISE NOTICE 'Calling PROC_DV_JOB_SCREEN_REFRESH';
	V_RETURN_MSG := PROC_DV_JOB_SCREEN_REFRESH();
	V_STATUS := SUBSTR(V_RETURN_MSG, 1, 1);
	IF V_STATUS = 0 THEN
		RAISE EXCEPTION '%', V_RETURN_MSG;
	END IF;		

--============================================================================
-- Final settings
--============================================================================

RETURN '1';

EXCEPTION
WHEN OTHERS THEN
  V_SQL_ERROR := SQLERRM;
  V_MSGTEXT := 'Step: ' || V_STEP || ' (' || V_STEP_DESC || ')';
  RAISE NOTICE 'Screen run exception: %; Sql error: %' ,V_MSGTEXT, V_SQL_ERROR;
  DROP TABLE TEMP_DV_TABLE IF EXISTS;
	
  RETURN '0, ' || V_MSGTEXT || '; ' || V_SQL_ERROR;
  
END;
END_PROC;


