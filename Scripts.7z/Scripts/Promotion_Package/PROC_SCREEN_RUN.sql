CREATE OR REPLACE PROCEDURE PROC_SCREEN_RUN(VARARGS)
RETURNS CHARACTER VARYING(ANY)
LANGUAGE NZPLSQL 
AS
BEGIN_PROC
DECLARE

	--============================================================================
	-- Input variables
	--============================================================================
	
	P_SCREEN_TK ALIAS FOR $1;
	P_JOB_TK ALIAS FOR $2;
	P_JOB_RUN_TK ALIAS FOR $3;
	
	--============================================================================
	-- Control variables used in most procedures
	--============================================================================

	V_MSGTEXT           VARCHAR(2000);  -- Text for audit_trail
	V_SQL               VARCHAR(4000);  -- Text for SQL statements
	V_STEP              INTEGER;       -- Indicator which part of the code was last executed when proc execution failed
	V_STEP_DESC			VARCHAR(255);  -- Description of the step (part of the code)
	V_INSERT_COUNT      BIGINT;        -- No of records inserted
	V_COUNT             BIGINT;        -- General counter
	V_ROW_COUNT			BIGINT;        -- General row count
	V_SQL_ERROR         VARCHAR(2000);  -- Sql error code for audit trail as varchar
	
	--============================================================================
	-- Procedure variables
	--============================================================================
	V_START_TIME TIMESTAMP;
	V_LOG_TIME TIMESTAMP;
	V_START_DATE_TK BIGINT;
	V_JOB_SCREEN_RUN_TK BIGINT;
	V_REC RECORD;
	V_SCREEN_DESCRIPTION CHARACTER VARYING(255);
	V_SCREEN_SPECIFIC_SQL NATIONAL CHARACTER VARYING(4000);
	V_NR_OF_EVENTS_2_RECORD BIGINT;
	V_TOTAL_RECORDS_QT_SQL NATIONAL CHARACTER VARYING(2000);
	V_TOTAL_RECORDS_QT BIGINT;
	V_SAVE_GOOD_RUN_TOTAL_COUNT CHAR(1);
	V_VIOLATED_RECORDS_QT BIGINT;
	V_TOTAL_RECORDS_BOOLEAN BOOLEAN ;
	
BEGIN	
	
	--============================================================================
	V_STEP := 100;
	V_STEP_DESC := 'Initial variables setup';
	--============================================================================
	
	V_START_TIME := CURRENT_TIMESTAMP;
	V_LOG_TIME := CURRENT_TIMESTAMP;
	V_START_DATE_TK := CAST(TO_CHAR(V_START_TIME, 'YYYYMMDD') AS BIGINT);
	V_JOB_SCREEN_RUN_TK := NEXT VALUE FOR F_JOB_SCREEN_RUN_SEQ;
	V_TOTAL_RECORDS_QT := NULL;
	
	SELECT SCREEN_DESCRIPTION, SCREEN_SPECIFIC_SQL, NR_OF_EVENTS_2_RECORD, TOTAL_RECORDS_QT_SQL, NVL(SAVE_GOOD_RUN_TOTAL_COUNT, 'N')
		INTO V_SCREEN_DESCRIPTION, V_SCREEN_SPECIFIC_SQL, V_NR_OF_EVENTS_2_RECORD, V_TOTAL_RECORDS_QT_SQL, V_SAVE_GOOD_RUN_TOTAL_COUNT 
	FROM D_SCREEN WHERE SCREEN_TK = P_SCREEN_TK;
	COMMIT;
	RAISE NOTICE 'Step: % (%); V_SCREEN_DESCRIPTION: %; V_SCREEN_SPECIFIC_SQL: %, TIME: %', V_STEP, V_STEP_DESC, V_SCREEN_DESCRIPTION, V_SCREEN_SPECIFIC_SQL, V_LOG_TIME;
	--============================================================================
	V_STEP := 200;
	V_STEP_DESC := 'Creating and populating TEMP_F_SCREEN_EVENTS table';
	--============================================================================
	V_LOG_TIME := CURRENT_TIMESTAMP;
	V_SQL := 'CREATE TABLE TEMP_F_SCREEN_EVENTS' || V_JOB_SCREEN_RUN_TK || ' AS ' || V_SCREEN_SPECIFIC_SQL; 
	EXECUTE IMMEDIATE V_SQL;
	V_VIOLATED_RECORDS_QT := ROW_COUNT;
	COMMIT;
	RAISE NOTICE 'Step: % (%); V_VIOLATED_RECORDS_QT: %, TIME: %', V_STEP, V_STEP_DESC, V_VIOLATED_RECORDS_QT, V_LOG_TIME;
	--============================================================================
	V_STEP := 300;
	V_STEP_DESC := 'Get V_TOTAL_RECORDS_QT';
	--============================================================================
	V_LOG_TIME := CURRENT_TIMESTAMP;
	V_TOTAL_RECORDS_BOOLEAN := (V_VIOLATED_RECORDS_QT > 0 OR V_SAVE_GOOD_RUN_TOTAL_COUNT = 'Y');
	IF V_TOTAL_RECORDS_BOOLEAN THEN

		V_SQL := 'CREATE TEMP TABLE TEMP_TOTAL_RECORDS_QT' || V_JOB_SCREEN_RUN_TK || ' AS ' || V_TOTAL_RECORDS_QT_SQL ;
		EXECUTE IMMEDIATE V_SQL;
--		SELECT V_TOTAL_RECORDS_QT := ROW_COUNT;

	END IF;
	COMMIT;
	RAISE NOTICE 'Step: % (%); V_TOTAL_RECORDS_QT: %, TIME: %', V_STEP, V_STEP_DESC, V_TOTAL_RECORDS_QT, V_LOG_TIME;
	--============================================================================
	V_STEP := 350;
	V_STEP_DESC := 'Update F_JOB_SCREEN_RUN: DM_CURRENT = ''N''';
	--============================================================================
	
--	UPDATE F_JOB_SCREEN_RUN
--		SET DM_CURRENT = 'N'
--	WHERE SCREEN_TK = P_SCREEN_TK
--		AND DM_CURRENT = 'Y'
--	;
--	V_ROW_COUNT :=  ROW_COUNT;
--	
--	RAISE NOTICE 'Step: % (%); V_ROW_COUNT: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;

	--============================================================================
	V_STEP := 400;
	V_STEP_DESC := 'Insert into F_JOB_SCREEN_RUN';
	--============================================================================
	V_LOG_TIME := CURRENT_TIMESTAMP;
	V_SQL := 'INSERT INTO F_JOB_SCREEN_RUN (JOB_SCREEN_RUN_TK
	   , JOB_RUN_TK
       , SCREEN_TK
       , JOB_TK
       , SCREEN_RUN_START_DATE_TK
       , SCREEN_RUN_START_TIMESTAMP
       , SCREEN_RUN_TIME_SECONDS
       , SCREEN_RESULT
       , VIOLATED_RECORDS_QT
       , TOTAL_RECORDS_QT
	) VALUES (
	     ' || V_JOB_SCREEN_RUN_TK || '
	   , ' || P_JOB_RUN_TK || ' 	 
	   , ' || P_SCREEN_TK || ' 
       , ' || P_JOB_TK || ' 
       , ' || V_START_DATE_TK || ' 
	   , ''' || V_START_TIME || ''' 
	   , EXTRACT(DAY FROM (CURRENT_TIMESTAMP - ''' || V_START_TIME || ''')*86400) 
       , CASE WHEN ' || V_VIOLATED_RECORDS_QT || ' > 0 THEN ''Violated'' ELSE ''OK'' END
       , ' || V_VIOLATED_RECORDS_QT || ' 
       , ' || CASE 
	   		WHEN V_TOTAL_RECORDS_BOOLEAN THEN '( SELECT TOTAL_RECORDS_QT FROM TEMP_TOTAL_RECORDS_QT' || V_JOB_SCREEN_RUN_TK || ' )'
			ELSE ' NULL ' END 
	|| ' )';
	RAISE NOTICE 'V_SQL: %', V_SQL;
	
	EXECUTE IMMEDIATE V_SQL;
	COMMIT;
		
	RAISE NOTICE 'Step: % (%); V_JOB_SCREEN_RUN_TK: %, TIME: %', V_STEP, V_STEP_DESC, V_JOB_SCREEN_RUN_TK, V_LOG_TIME;
	
	--============================================================================
	V_STEP := 500;
	V_STEP_DESC := 'Insert into F_SCREEN_EVENTS';
	--============================================================================
	V_LOG_TIME := CURRENT_TIMESTAMP;	
	V_SQL := 'INSERT INTO F_SCREEN_EVENTS (JOB_SCREEN_RUN_TK
       , SCREEN_TK
       , TABLE_TK
       , TABLE_ROWID
       , SCREEN_EVENT_NB
       , SCREEN_RUN_DATE_TK
       , SCREEN_RUN_TIME
       , SCREEN_VIOLATION_CONDITION
		) 
	   SELECT ' || V_JOB_SCREEN_RUN_TK
       || ', ' || P_SCREEN_TK
       || ', A.TABLE_TK
       , A.TABLE_ROWID
       , A.SCREEN_EVENT_NB'
       || ', ' || V_START_DATE_TK
       || ', TO_TIMESTAMP(''' || TO_CHAR(V_START_TIME, 'YYYYMMDD HH24:MI:SS') || ''', ''YYYYMMDD HH24:MI:SS'')'
       || ', A.SCREEN_VIOLATION_CONDITION
	   FROM TEMP_F_SCREEN_EVENTS' || V_JOB_SCREEN_RUN_TK || ' A '
	   || ' ORDER BY SCREEN_EVENT_NB, TABLE_ROWID '
	   || CASE WHEN V_NR_OF_EVENTS_2_RECORD IS NULL THEN '' ELSE 'LIMIT ' || V_NR_OF_EVENTS_2_RECORD END 
	   ;
	RAISE NOTICE 'V_SQL: %', V_SQL;
	EXECUTE IMMEDIATE V_SQL;
	COMMIT;
	RAISE NOTICE 'Step: % (%); V_NR_OF_EVENTS_2_RECORD: %, TIME: %', V_STEP, V_STEP_DESC, V_NR_OF_EVENTS_2_RECORD, V_LOG_TIME;
	--============================================================================
	V_STEP := 600;
	V_STEP_DESC := 'Delete from F_SCREEN_EVENTS old run events';
	
	--============================================================================

--	DELETE FROM F_SCREEN_EVENTS
--	WHERE SCREEN_TK = P_SCREEN_TK
--		AND JOB_SCREEN_RUN_TK <> V_JOB_SCREEN_RUN_TK
--	;
--	V_ROW_COUNT :=  ROW_COUNT;
--	
--	RAISE NOTICE 'Step: % (%); V_ROW_COUNT: ', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	--============================================================================
	V_STEP := 700;
	V_STEP_DESC := 'Drop temp tables';
	--============================================================================
	V_LOG_TIME := CURRENT_TIMESTAMP;
	V_SQL := 'DROP TABLE TEMP_F_SCREEN_EVENTS' || V_JOB_SCREEN_RUN_TK || ' IF EXISTS; '
		||  'DROP TABLE TEMP_TOTAL_RECORDS_QT' || V_JOB_SCREEN_RUN_TK || ' IF EXISTS';
	EXECUTE IMMEDIATE V_SQL;
	RAISE NOTICE 'Step: % (%), TIME: %', V_STEP, V_STEP_DESC, V_LOG_TIME;
	
--============================================================================
-- Final settings
--============================================================================

RETURN '1';

EXCEPTION
WHEN OTHERS THEN
  V_SQL_ERROR := SQLERRM;
  V_MSGTEXT := 'SCREEN_TK: ' || P_SCREEN_TK
  	|| ' (' || V_SCREEN_DESCRIPTION || '); '
	|| 'Step: ' || V_STEP || ' (' || V_STEP_DESC || ')';
  RAISE NOTICE 'Screen run exception: %; Sql error: %' ,V_MSGTEXT, V_SQL_ERROR;
  V_SQL := 'DROP TABLE TEMP_TOTAL_RECORDS_QT' || V_JOB_SCREEN_RUN_TK || ' IF EXISTS; '
		|| 'DROP TABLE TEMP_F_SCREEN_EVENTS' || V_JOB_SCREEN_RUN_TK || ' IF EXISTS';
  EXECUTE IMMEDIATE V_SQL;
	
  RETURN '0, ' || V_MSGTEXT || '; ' || V_SQL_ERROR;
  
END;
END_PROC;
