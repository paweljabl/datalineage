CREATE OR REPLACE PROCEDURE PROC_DV_TABLE_REFRESH (VARARGS)
RETURNS CHARACTER VARYING(ANY)
LANGUAGE NZPLSQL 
AS
BEGIN_PROC
DECLARE

	--============================================================================
	-- Input variables
	--============================================================================
	
	P_ENV ALIAS FOR $1;
--	P_INPUT_VARIABLE_2 ALIAS FOR $2;

	--============================================================================
	-- Control variables used in most procedures
	--============================================================================

	V_MSGTEXT           VARCHAR(2000);  -- Text for audit_trail
	V_SQL               VARCHAR(4000);  -- Text for SQL statements
	V_STEP              INTEGER;       -- Indicator which part of the code was last executed when proc execution failed
	V_STEP_DESC			VARCHAR(255);  -- Description of the step (part of the code)
	V_INSERT_COUNT      BIGINT;        -- No of records inserted
	V_COUNT             BIGINT;        -- General counter
	V_ROW_COUNT			BIGINT;        -- General row count
	V_SQL_ERROR         VARCHAR(2000);  -- Sql error code for audit trail as varchar
	
	--============================================================================
	-- Procedure variables
	--============================================================================
	V_START_TIME TIMESTAMP;
	
BEGIN	
	
	--============================================================================
	V_STEP := 100;
	V_STEP_DESC := 'Initial variables setup / temp table creation with input';
	--============================================================================
	
	V_START_TIME := CURRENT_TIMESTAMP;
	
	V_SQL = 'CREATE TEMP TABLE TEMP_DV_TABLE AS 
	SELECT SUBSTR(DATABASE, 1, INSTR(DATABASE, ''_'', 1) - 1) AS ENV, DATABASE AS DATABASE_NAME, TABLENAME
	FROM ' || P_ENV || '_EDW_DATAVAULT.._V_TABLE
	WHERE DATABASE <> ''SYSTEM''';
	EXECUTE IMMEDIATE V_SQL;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Total number of tables: %', V_STEP, V_STEP_DESC, V_ROW_COUNT;
	--============================================================================
	V_STEP := 200;
	V_STEP_DESC := 'Inserting new / changed tables to D_TABLE';
	--============================================================================
	
	INSERT INTO D_TABLE (TABLE_TK,  NAME, SUBJECT_AREA, TECHNICAL_AREA, ENVIRONMENT, DATABASE_NAME, OBJECT_TYPE, OBJECT_TYPE_CODE, DELETE_FLAG, DM_INSERT_TIMESTAMP)  
	SELECT NEXT VALUE FOR D_TABLE_SEQ
	, A.*
	, 'N' AS DELETE_FLAG
	, V_START_TIME AS DM_INSERT_TIMESTAMP
	FROM ( 
		SELECT T.TABLENAME AS NAME 
		, CASE 
			WHEN TABLENAME like 'SAT_%' THEN substr(T.TABLENAME, 5, instr(T.TABLENAME, '_', 5) - 5)
			WHEN TABLENAME like 'STAGE_LNK%' THEN substr(T.TABLENAME, 11, instr(T.TABLENAME, '_', 11) - 11) 
			WHEN TABLENAME like 'STAGE_TLNK%' THEN substr(T.TABLENAME, 12, instr(T.TABLENAME, '_', 12) - 12) 
			WHEN TABLENAME like 'STAGE%' THEN substr(T.TABLENAME, 7, instr(T.TABLENAME, '_', 7) - 7) 
			ELSE 'EDW' END AS SUBJECT_AREA
		, 'Data Vault' AS TECHNICAL_AREA
		, ENV AS ENVIRONMENT
		, ENV || '_EDW_DATAVAULT' AS DATABASE_NAME
		, CASE 
			WHEN TABLENAME like 'SAT_%' THEN 'Satellite'
			WHEN TABLENAME like 'STAGE_LNK%' THEN 'Stage Table'
			WHEN TABLENAME like 'STAGE_TLNK%' THEN 'Stage Table'
			WHEN TABLENAME like 'STAGE%' THEN 'Stage Table'
			WHEN TABLENAME like 'TLNK%' THEN 'Link'
			WHEN TABLENAME like 'LNK%' THEN 'Link'
			WHEN TABLENAME like 'HUB%' THEN 'Hub'
			WHEN TABLENAME like 'REF%' THEN 'Hub'
			ELSE 'Unk' END AS OBJECT_TYPE
		, CASE 
			WHEN TABLENAME like 'SAT_%' THEN 'SAT'
			WHEN TABLENAME like 'STAGE_LNK%' THEN 'STAGE'
			WHEN TABLENAME like 'STAGE_TLNK%' THEN 'STAGE'
			WHEN TABLENAME like 'STAGE%' THEN 'STAGE'
			WHEN TABLENAME like 'TLNK%' THEN 'LNK'
			WHEN TABLENAME like 'LNK%' THEN 'LNK'
			WHEN TABLENAME like 'HUB%' THEN 'HUB'
			WHEN TABLENAME like 'REF%' THEN 'HUB'
			ELSE 'Unk' END AS OBJECT_TYPE_CODE
		FROM TEMP_DV_TABLE T
		LEFT JOIN D_TABLE DT ON T.DATABASE_NAME = DT.DATABASE_NAME
			AND T.TABLENAME = DT.NAME
		WHERE DT.TABLE_TK IS NULL
			AND DT.DELETE_FLAG = 'N'
	) A	
	WHERE A.OBJECT_TYPE <> 'Unk'
	ORDER BY NAME;

	RAISE NOTICE 'Step: % (%); Inserted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	--============================================================================
	V_STEP := 300;
	V_STEP_DESC := 'Setting DELETE_FLAG in D_TABLE to ''Y'' for tables that no longer exist';
	--============================================================================
	
	UPDATE D_TABLE T
		SET DELETE_FLAG = 'Y'
		, DM_UPDATE_TIMESTAMP = V_START_TIME
	WHERE T.TECHNICAL_AREA = 'Data Vault'
		AND T.ENVIRONMENT = P_ENV
		AND (T.DATABASE_NAME, T.NAME) NOT IN (
			SELECT DATABASE_NAME, TABLENAME AS NAME
			FROM TEMP_DV_TABLE
		)
	;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Updated records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	--============================================================================
	V_STEP := 400;
	V_STEP_DESC := 'Drop temp tables';
	--============================================================================
	
	DROP TABLE TEMP_DV_TABLE IF EXISTS;
	RAISE NOTICE 'Step: % (%)', V_STEP, V_STEP_DESC ;
	
--============================================================================
-- Final settings
--============================================================================

RETURN '1';

EXCEPTION
WHEN OTHERS THEN
  V_SQL_ERROR := SQLERRM;
  V_MSGTEXT := 'Step: ' || V_STEP || ' (' || V_STEP_DESC || ')';
  RAISE NOTICE 'Screen run exception: %; Sql error: %' ,V_MSGTEXT, V_SQL_ERROR;
  DROP TABLE TEMP_DV_TABLE IF EXISTS;
	
  RETURN '0, ' || V_MSGTEXT || '; ' || V_SQL_ERROR;
  
END;
END_PROC;
