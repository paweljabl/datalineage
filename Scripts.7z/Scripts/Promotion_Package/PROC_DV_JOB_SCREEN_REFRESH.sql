CREATE OR REPLACE PROCEDURE PROC_DV_JOB_SCREEN_REFRESH ()
RETURNS CHARACTER VARYING(ANY)
LANGUAGE NZPLSQL 
AS
BEGIN_PROC
DECLARE

	--============================================================================
	-- Input variables
	--============================================================================
	
--	P_INPUT_VARIABLE_2 ALIAS FOR $2;

	--============================================================================
	-- Control variables used in most procedures
	--============================================================================

	V_MSGTEXT           VARCHAR(2000);  -- Text for audit_trail
	V_SQL               VARCHAR(4000);  -- Text for SQL statements
	V_STEP              INTEGER;       -- Indicator which part of the code was last executed when proc execution failed
	V_STEP_DESC			VARCHAR(255);  -- Description of the step (part of the code)
	V_INSERT_COUNT      BIGINT;        -- No of records inserted
	V_COUNT             BIGINT;        -- General counter
	V_ROW_COUNT			BIGINT;        -- General row count
	V_SQL_ERROR         VARCHAR(2000);  -- Sql error code for audit trail as varchar
	
	--============================================================================
	-- Procedure variables
	--============================================================================
	V_START_TIME TIMESTAMP;
	
BEGIN	
	
	--============================================================================
	V_STEP := 100;
	V_STEP_DESC := 'Initial variables setup ';
	--============================================================================
	
	V_START_TIME := CURRENT_TIMESTAMP;
	
	--============================================================================
	V_STEP := 200;
	V_STEP_DESC := 'Deleting "Deleted" Screens';
	--============================================================================
	
	DELETE FROM H_JOB_SCREEN	
	WHERE SCREEN_TK NOT IN (SELECT SCREEN_TK FROM D_SCREEN WHERE DELETE_FLAG = 'N');

	V_ROW_COUNT :=  ROW_COUNT;
	RAISE NOTICE 'Step: % (%); Deleted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	
	--============================================================================
	V_STEP := 300;
	V_STEP_DESC := 'Inserting new records';
	--============================================================================
	
	INSERT INTO H_JOB_SCREEN (JOB_TK
       , SCREEN_TK
       , PROCESSING_ORDER_NB
	   , ENVIRONMENT
	   , DM_INSERT_TIMESTAMP
	) 
	SELECT J.JOB_TK
	, S.SCREEN_TK
	, (ROW_NUMBER() OVER (PARTITION BY T.ENVIRONMENT, J.JOB_TK ORDER BY SCREEN_TK)) * 100 + NVL(MAX_NB, 0) AS PROCESSING_ORDER_NB
	, S.ENVIRONMENT
	, V_START_TIME AS DM_INSERT_TIMESTAMP
	FROM (
		SELECT SUBJECT_AREA, ENVIRONMENT, NAME, TABLE_TK
		FROM D_TABLE
		WHERE TECHNICAL_AREA = 'Data Vault'
			AND DELETE_FLAG = 'N'
		UNION 
		SELECT DISTINCT TA.SUBJECT_AREA, TB.ENVIRONMENT, TB.NAME, TB.TABLE_TK
		FROM D_TABLE_RELATION R
		JOIN D_TABLE TA ON R.TABLE_TK_A = TA.TABLE_TK
			AND TA.TECHNICAL_AREA = 'Data Vault'
		JOIN D_TABLE TB ON R.TABLE_TK_B = TB.TABLE_TK
		WHERE R.RELATION_TYPE = 'FK_PK_I'
			AND R.DELETE_FLAG = 'N'
	) T
	JOIN D_SCREEN S ON S.TABLE_TK = T.TABLE_TK
	JOIN D_JOB J ON T.SUBJECT_AREA = J.JOB_NAME
	LEFT JOIN (SELECT ENVIRONMENT, JOB_TK, MAX(PROCESSING_ORDER_NB) AS MAX_NB 
			FROM H_JOB_SCREEN 
			GROUP BY ENVIRONMENT, JOB_TK
		) M ON M.ENVIRONMENT = T.ENVIRONMENT
		AND M.JOB_TK = J.JOB_TK 
	LEFT JOIN H_JOB_SCREEN H ON J.JOB_TK = H.JOB_TK
		AND S.SCREEN_TK = H.SCREEN_TK
	WHERE H.JOB_TK IS NULL
		AND S.DELETE_FLAG = 'N'
	;
	V_ROW_COUNT :=  ROW_COUNT;
	RAISE NOTICE 'Step: % (%); Inserted records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;

--============================================================================
-- Final settings
--============================================================================

RETURN '1';

EXCEPTION
WHEN OTHERS THEN
  V_SQL_ERROR := SQLERRM;
  V_MSGTEXT := 'Step: ' || V_STEP || ' (' || V_STEP_DESC || ')';
  RAISE NOTICE 'Screen run exception: %; Sql error: %' ,V_MSGTEXT, V_SQL_ERROR;
  DROP TABLE TEMP_DV_TABLE IF EXISTS;
	
  RETURN '0, ' || V_MSGTEXT || '; ' || V_SQL_ERROR;
  
END;
END_PROC;
