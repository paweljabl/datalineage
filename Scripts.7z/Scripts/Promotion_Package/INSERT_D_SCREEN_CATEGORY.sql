DROP TABLE TMP_SCREEN_CATEGORY IF EXISTS;

CREATE TABLE TMP_SCREEN_CATEGORY AS 
SELECT SCREEN_CATEGORY_CODE
   , SCREEN_CATAGORY
   , SCREEN_TYPE
   , SCREEN_CODE_DEFINITION
   , SCREEN_NAME
   , SCREEN_DEFINITION
   , SCREEN_SQL_TYPE
   , SCREEN_GENERIC_SQL
   , DM_INSERT_TIMESTAMP
FROM D_SCREEN_CATEGORY
WHERE 1 = 0 ;


INSERT INTO TMP_SCREEN_CATEGORY (SCREEN_CATEGORY_CODE
	   , SCREEN_CATAGORY
       , SCREEN_TYPE
	   , SCREEN_CODE_DEFINITION
       , SCREEN_NAME
       , SCREEN_DEFINITION
       , SCREEN_SQL_TYPE
       , SCREEN_GENERIC_SQL
	   , DM_INSERT_TIMESTAMP
) VALUES ('UIX'
	, 'Structure screen'
	, 'Uniqueness'
	, 'S(UIX)#T(D_TABLE.TABLE_TK)#T(D_UNIQUE_INDEX.UNIQUE_INDEX_TK)'
	, 'Unique combination of columns'
	, 'Uniqueness of unique constraint / index columns'
	, 'SQL Select'
	, NULL
	, CURRENT_TIMESTAMP
);

INSERT INTO TMP_SCREEN_CATEGORY (SCREEN_CATEGORY_CODE
       , SCREEN_CATAGORY
       , SCREEN_TYPE
	   , SCREEN_CODE_DEFINITION
       , SCREEN_NAME
       , SCREEN_DEFINITION
       , SCREEN_SQL_TYPE
       , SCREEN_GENERIC_SQL
	   , DM_INSERT_TIMESTAMP
) VALUES ('PK'
	, 'Structure screen'
	, 'Uniqueness'
	, 'S(PK)#T(D_TABLE.TABLE_TK)'
	, 'Unique combination of columns'
	, 'Uniqueness of primary key columns'
	, 'SQL Select'
	, NULL
	, CURRENT_TIMESTAMP
);

INSERT INTO TMP_SCREEN_CATEGORY (SCREEN_CATEGORY_CODE
	   , SCREEN_CATAGORY
       , SCREEN_TYPE
	   , SCREEN_CODE_DEFINITION
       , SCREEN_NAME
       , SCREEN_DEFINITION
       , SCREEN_SQL_TYPE
       , SCREEN_GENERIC_SQL
	   , DM_INSERT_TIMESTAMP
) VALUES ('DV_CUR_F'
	, 'Structure screen'
	, 'Correct values'
	, 'S(DV_CUR_F)#T(D_TABLE.TABLE_TK)'
	, 'DV_CURRENT_FLAG correct values'
	, 'DV_CURRENT_FLAG has always one ''Y'' and rest are ''N'' per business key (sid)'
	, 'SQL Select'
	, NULL
	, CURRENT_TIMESTAMP
);

INSERT INTO TMP_SCREEN_CATEGORY (SCREEN_CATEGORY_CODE
	   , SCREEN_CATAGORY
       , SCREEN_TYPE
	   , SCREEN_CODE_DEFINITION
       , SCREEN_NAME
       , SCREEN_DEFINITION
       , SCREEN_SQL_TYPE
       , SCREEN_GENERIC_SQL
	   , DM_INSERT_TIMESTAMP
) VALUES ('DV_SID'
	, 'Structure screen'
	, 'Correct values'
	, 'S(DV_SID)#T(D_TABLE.TABLE_TK)'
	, 'SID > 0'
	, 'SID columns values shouldn''t be 0'
	, 'SQL Select'
	, NULL
	, CURRENT_TIMESTAMP
);

INSERT INTO TMP_SCREEN_CATEGORY (SCREEN_CATEGORY_CODE
	   , SCREEN_CATAGORY
       , SCREEN_TYPE
	   , SCREEN_CODE_DEFINITION
       , SCREEN_NAME
       , SCREEN_DEFINITION
       , SCREEN_SQL_TYPE
       , SCREEN_GENERIC_SQL
	   , DM_INSERT_TIMESTAMP
) VALUES ('STOV_2_DM'
	, 'Business rule screen'
	, 'Completeness'
	, 'S(STOV_2_DM)#T((STOV)D_TABLE.TABLE_TK)#T((DM)D_TABLE.TABLE_TK)'
	, 'STOV 2 DM check'
	, 'Checking if all valid (based on business rule) STOV records are covered in DM table'
	, 'SQL Select'
	, NULL
	, CURRENT_TIMESTAMP
);

INSERT INTO TMP_SCREEN_CATEGORY (SCREEN_CATEGORY_CODE
	   , SCREEN_CATAGORY
       , SCREEN_TYPE
	   , SCREEN_CODE_DEFINITION
       , SCREEN_NAME
       , SCREEN_DEFINITION
       , SCREEN_SQL_TYPE
       , SCREEN_GENERIC_SQL
	   , DM_INSERT_TIMESTAMP
) VALUES ('CNT'
	, 'Info screen'
	, 'Information'
	, 'S(CNT)#T(D_TABLE.TABLE_TK)'
	, 'Table row count'
	, 'Number of records in a table / view'
	, 'SQL Select'
	, NULL
	, CURRENT_TIMESTAMP
);

INSERT INTO TMP_SCREEN_CATEGORY (SCREEN_CATEGORY_CODE
	   , SCREEN_CATAGORY
       , SCREEN_TYPE
	   , SCREEN_CODE_DEFINITION
       , SCREEN_NAME
       , SCREEN_DEFINITION
       , SCREEN_SQL_TYPE
       , SCREEN_GENERIC_SQL
	   , DM_INSERT_TIMESTAMP
) VALUES ('COL'
	, 'Column screen'
	, 'Information'
	, 'S(COL)#T(D_TABLE.TABLE_TK).#T(D_TABLE_COLUMN.TABLE_COLUMN_TK)'
	, 'Column values are valid'
	, 'Column values are valid business-wise / technical-wise'
	, 'SQL Select'
	, NULL
	, CURRENT_TIMESTAMP
);

INSERT INTO D_SCREEN_CATEGORY (SCREEN_CATEGORY_TK
       , SCREEN_CATEGORY_CODE
	   , SCREEN_CATAGORY
       , SCREEN_TYPE
	   , SCREEN_CODE_DEFINITION
       , SCREEN_NAME
       , SCREEN_DEFINITION
       , SCREEN_SQL_TYPE
       , SCREEN_GENERIC_SQL
	   , DM_INSERT_TIMESTAMP
)
SELECT NEXT VALUE FOR D_SCREEN_CATEGORY_SEQ
, T.*
FROM TMP_SCREEN_CATEGORY T
LEFT JOIN D_SCREEN_CATEGORY SC ON T.SCREEN_CATEGORY_CODE = SC.SCREEN_CATEGORY_CODE
WHERE SC.SCREEN_CATEGORY_TK IS NULL
;