CREATE OR REPLACE PROCEDURE PROC_DV_TABLE_COLUMN_REFRESH (VARARGS)
RETURNS CHARACTER VARYING(ANY)
LANGUAGE NZPLSQL 
AS
BEGIN_PROC
DECLARE

	--============================================================================
	-- Input variables
	--============================================================================
	
	P_ENV ALIAS FOR $1;
--	P_INPUT_VARIABLE_2 ALIAS FOR $2;

	--============================================================================
	-- Control variables used in most procedures
	--============================================================================

	V_MSGTEXT           VARCHAR(2000);  -- Text for audit_trail
	V_SQL               VARCHAR(4000);  -- Text for SQL statements
	V_STEP              INTEGER;       -- Indicator which part of the code was last executed when proc execution failed
	V_STEP_DESC			VARCHAR(255);  -- Description of the step (part of the code)
	V_INSERT_COUNT      BIGINT;        -- No of records inserted
	V_COUNT             BIGINT;        -- General counter
	V_ROW_COUNT			BIGINT;        -- General row count
	V_SQL_ERROR         VARCHAR(2000);  -- Sql error code for audit trail as varchar
	
	--============================================================================
	-- Procedure variables
	--============================================================================
	V_START_TIME TIMESTAMP;
	
BEGIN	
	
	--============================================================================
	V_STEP := 100;
	V_STEP_DESC := 'Initial variables setup / temp table creation with input';
	--============================================================================
	
	V_START_TIME := CURRENT_TIMESTAMP;
	
	V_SQL = 'CREATE TEMP TABLE TEMP_DV_TABLE_COLUMN AS 
	SELECT TABLE_CAT, TABLE_NAME, COLUMN_NAME, ORDINAL_POSITION, DATA_TYPE, IS_NULLABLE 
	FROM ' || P_ENV || '_EDW_DATAVAULT.._V_ODBC_COLUMNS1';
	EXECUTE IMMEDIATE V_SQL;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Total number of tables: %', V_STEP, V_STEP_DESC, V_ROW_COUNT;

	--============================================================================
	V_STEP := 200;
	V_STEP_DESC := 'Inserting dummy, initial record to D_TABLE_COLUMN';
	--============================================================================
	
	INSERT INTO D_TABLE_COLUMN (TABLE_COLUMN_TK, TABLE_TK, ENVIRONMENT, SUBJECT_AREA, TABLE_NAME, COLUMN_NAME, COLUMN_ORDER, DATA_TYPE, NULLS_FLAG, DM_INSERT_TIMESTAMP)
	SELECT 0 AS TABLE_COLUMN_TK, 0 AS TABLE_TK, 'N/A' ENVIRONMENT, 'N/A' AS SUBJECT_AREA, 'N/A' AS TABLE_NAME, 'N/A' AS COLUMN_NAME, 0 AS COLUMN_ORDER, 'N/A' AS DATA_TYPE, 'Y' AS NULLS_FLAG, CURRENT_TIMESTAMP
	FROM (
		SELECT 0 AS TABLE_COLUMN_TK
		MINUS
		SELECT TABLE_COLUMN_TK 
		FROM D_TABLE_COLUMN
		WHERE TABLE_COLUMN_TK = 0
	) A;
	
	--============================================================================
	V_STEP := 300;
	V_STEP_DESC := 'Merging new / changed columns to D_TABLE_COLUMN';
	--============================================================================
	
	MERGE INTO D_TABLE_COLUMN AS A
	USING (
		SELECT 
		  TAB.TABLE_TK
		, TAB.ENVIRONMENT
		, TAB.SUBJECT_AREA
		, TAB.NAME AS TABLE_NAME
		, COL.COLUMN_NAME
		, COL.ORDINAL_POSITION AS COLUMN_ORDER
		, DECODE(COL.DATA_TYPE,-9,'NVARCHAR',-7,'BOOLEAN',-6,'BYTEINT',-5,'BIGINT',1,'CHAR',2,'NUMERIC',4,'INTEGER',5,'SMALLINT',7,'FLOAT',8,'DOUBLE',12,'VARCHAR',91,'DATE',92,'TIME',93,'TIMESTAMP') AS DATA_TYPE
		, CASE WHEN COL.IS_NULLABLE = 'YES' THEN 'N' ELSE 'Y' END AS NULLS_FLAG
		, CASE WHEN SST.BUSINESS_KEY_IND NOT IN ('N', 'Y')  THEN 'Y' ELSE 'N' END AS PRIMARY_KEY_FLAG
		FROM D_TABLE TAB
		INNER JOIN TEMP_DV_TABLE_COLUMN COL ON TAB.NAME = COL.TABLE_NAME
			AND TAB.DATABASE_NAME = COL.TABLE_CAT
		LEFT JOIN SST_TABLE_COLUMN_DV SST ON TAB.ENVIRONMENT = SST.ENV 
			AND COL.TABLE_NAME = SST.TABLE_NAME
			AND COL.COLUMN_NAME = SST.COL_NAME
		WHERE TAB.TECHNICAL_AREA = 'Data Vault'	
			AND TAB.DELETE_FLAG = 'N'
		MINUS
		SELECT TABLE_TK, ENVIRONMENT, SUBJECT_AREA, TABLE_NAME, COLUMN_NAME, COLUMN_ORDER, DATA_TYPE, NULLS_FLAG, PRIMARY_KEY_FLAG
		FROM D_TABLE_COLUMN
		WHERE DELETE_FLAG = 'N'
	) AS B 
		ON A.TABLE_TK = B.TABLE_TK
			AND A.COLUMN_NAME = B.COLUMN_NAME
	WHEN MATCHED THEN
		UPDATE SET A.COLUMN_ORDER = B.COLUMN_ORDER
			, A.DATA_TYPE = B.DATA_TYPE
			, A.NULLS_FLAG = B.NULLS_FLAG
			, A.PRIMARY_KEY_FLAG = B.PRIMARY_KEY_FLAG
			, A.DM_UPDATE_TIMESTAMP = V_START_TIME
	WHEN NOT MATCHED THEN 
	INSERT (TABLE_COLUMN_TK, TABLE_TK, ENVIRONMENT, SUBJECT_AREA, TABLE_NAME, COLUMN_NAME, COLUMN_ORDER, DATA_TYPE, NULLS_FLAG, PRIMARY_KEY_FLAG, DELETE_FLAG, DM_INSERT_TIMESTAMP)
		VALUES (NEXT VALUE FOR D_TABLE_COLUMN_SEQ, B.TABLE_TK, B.ENVIRONMENT, B.SUBJECT_AREA, B.TABLE_NAME, B.COLUMN_NAME, B.COLUMN_ORDER, B.DATA_TYPE, B.NULLS_FLAG, B.PRIMARY_KEY_FLAG, 'N', V_START_TIME)
	;

	RAISE NOTICE 'Step: % (%);', V_STEP, V_STEP_DESC ;
	--============================================================================
	V_STEP := 400;
	V_STEP_DESC := 'Setting DELETE_FLAG in D_TABLE_COLUMN to ''Y'' for tables / columns that no longer exist';
	--============================================================================
	
	UPDATE D_TABLE_COLUMN T
		SET DELETE_FLAG = 'Y'
		, DM_UPDATE_TIMESTAMP = V_START_TIME
	FROM D_TABLE TAB
	WHERE  T.TABLE_TK = TAB.TABLE_TK
		AND TAB.TECHNICAL_AREA = 'Data Vault'
		AND T.TABLE_COLUMN_TK > 0 AND (T.TABLE_TK, T.COLUMN_NAME) NOT IN (
			SELECT TAB.TABLE_TK, COL.COLUMN_NAME
			FROM D_TABLE TAB
			INNER JOIN TEMP_DV_TABLE_COLUMN COL ON TAB.NAME = COL.TABLE_NAME
				AND TAB.DATABASE_NAME = COL.TABLE_CAT
		)
	;
	V_ROW_COUNT :=  ROW_COUNT;
	
	RAISE NOTICE 'Step: % (%); Updated records: %', V_STEP, V_STEP_DESC, V_ROW_COUNT ;
	--============================================================================
	V_STEP := 500;
	V_STEP_DESC := 'Drop temp tables';
	--============================================================================
	
	DROP TABLE TEMP_DV_TABLE_COLUMN IF EXISTS;
	RAISE NOTICE 'Step: % (%)', V_STEP, V_STEP_DESC ;
	
--============================================================================
-- Final settings
--============================================================================

RETURN '1';

EXCEPTION
WHEN OTHERS THEN
  V_SQL_ERROR := SQLERRM;
  V_MSGTEXT := 'Step: ' || V_STEP || ' (' || V_STEP_DESC || ')';
  RAISE NOTICE 'Screen run exception: %; Sql error: %' ,V_MSGTEXT, V_SQL_ERROR;
  DROP TABLE TEMP_DV_TABLE_COLUMN IF EXISTS;
	
  RETURN '0, ' || V_MSGTEXT || '; ' || V_SQL_ERROR;
  
END;
END_PROC;
