SELECT OO_NAME
, OO_ACTIVE
, OC_OBJ_KEY
, OC_COL_KEY
, OC_COL_NAME
, OC_DISPLAY_NAME
, OC_DATA_TYPE
, OC_NULLS_FLAG
, OC_NUMERIC_FLAG
, OC_ADDITIVE_FLAG
, OC_ATTRIBUTE_FLAG
, OC_JOIN_FLAG
, OC_EUL_FLAG
, OC_FORMAT
, OC_SRC_TABLE
, OC_SRC_COLUMN
, OC_SRC_STRATEGY
, OC_ORDER
, OC_COL_TYPE
, OC_KEY_TYPE
, OC_BUSINESS_KEY_IND
, OC_ARTIFICIAL_KEY_IND
, OC_ATTRIBUTES
, OC_ZERO_KEY_VALUE
, OC_PRIMARY_INDEX_IND
, OC_DEFAULT_VALUE
, OC_CASE_FLAG
, OC_SUM_FLAG
, OC_COUNT_FLAG
, OC_GROUP_FLAG
, OC_ORDER_BY
, OC_TITLE
, OC_COMPRESS_FLAG
, OC_COMPRESS_VALUE
, OC_COMMENTS
, OC_UPDATE_FLAG
, OC_DISPLAY_TYPE
, OC_PRE_JOIN_SOURCE
, OC_IND_1
FROM DEV_DWHU_STAGING..POC_WH_OBJ_COLUMNS
where ( OO_NAME LIKE 'SAT_%' OR OO_NAME LIKE 'STAGE%' )
	and ( oc_join_flag = 'Y')
	and oo_name like '%KOLA%'
order by oo_name
LIMIT 100;
 
 select  w.OC_BUSINESS_KEY_IND , count(*)
 FROM DEV_DWHU_STAGING..POC_WH_OBJ_COLUMNS w
 group by w.OC_BUSINESS_KEY_IND 
 order by 1;
 
 select w.OC_BUSINESS_KEY_IND, w.*
 from( select OC_OBJ_KEY
 from DEV_DWHU_STAGING..POC_WH_OBJ_COLUMNS w
 where OC_BUSINESS_KEY_IND = '1'
 and oo_name like 'SAT_%'
 ) a
 join DEV_DWHU_STAGING..POC_WH_OBJ_COLUMNS w
 on a.OC_OBJ_KEY = w.OC_OBJ_KEY 
 order by OO_NAME, OC_ORDER ;
 
 select OC_OBJ_KEY, OC_COL_KEY
 from DEV_DWHU_STAGING..POC_WH_OBJ_COLUMNS w
 group by OC_OBJ_KEY, OC_COL_KEY
 having count(*) > 1;
 
 select LNK_CONTRACT_ASSET_SECURITIES_SID, SECURITY_TYPE_RAW, START_DATE_RAW
 from prod_edw_datavault..SAT_CMS_CONTRACT_ASSET_SECURITIES
 where dv_current_flag = 'Y'
 group by LNK_CONTRACT_ASSET_SECURITIES_SID, SECURITY_TYPE_RAW , START_DATE_RAW
 having count(*) > 1;
 
 select LNK_DEALER_PART_CALC_PERIOD_SID, PERIOD
 from prod_edw_datavault..SAT_DSP_DEALER_PART_CALC_PERIOD
 where dv_current_flag = 'Y'
 group by LNK_DEALER_PART_CALC_PERIOD_SID, PERIOD
 having count(*) > 1;
 
 
 select OC_BUSINESS_KEY_IND, count(*)
 from DEV_DWHU_STAGING..POC_WH_OBJ_COLUMNS w
 where oo_name like 'SAT_%'
 and OC_BUSINESS_KEY_IND not in ('N', 'Y')
 group by OC_BUSINESS_KEY_IND
 order by 2
 
 select * from DEV_DWHU_STAGING..POC_WH_OBJ_COLUMNS w
 where oo_name like 'SAT_%'
 	and OC_BUSINESS_KEY_IND in ('N', 'Y')
 order by oo_name;
 
 select substr(oo_name, 1, 3), count(distinct oo_name) from DEV_DWHU_STAGING..POC_WH_OBJ_COLUMNS w
 group by substr(oo_name, 1, 3)