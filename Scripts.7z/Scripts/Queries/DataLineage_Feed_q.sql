select * from SAT_VDA_TEA2PLUS_VEH_NODE_MAIN_SOFT
;
select distinct  'DV_' || ta.name as node_a
, 'absorbs' AS RELATION_TYPE
, R.RELATION_LEVEL 
, 'DV_' || tB.name as node_B
from D_TABLE_RELATION r
join d_table ta on r.TABLE_TK_A = ta.TABLE_TK
	and ta.technical_area = 'Data Vault'
	and ta.ENVIRONMENT = 'PROD'
join d_table tb on r.TABLE_TK_b = tb.TABLE_TK
	and tb.technical_area = 'Data Vault'
	and tb.ENVIRONMENT = 'PROD'
where ta.NAME = 'STAGE_LNK_AMM_BRAND_VEHICLE'
;

