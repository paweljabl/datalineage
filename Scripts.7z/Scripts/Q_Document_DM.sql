select * from PROD_DOCUMENT_DM.TN94766.DG_ENTITY_RELATIONSHIP;
select * from PROD_DOCUMENT_DM.TN94766.DG_OBJECT;
select * from PROD_DOCUMENT_DM.TN94766.DG_SOURCE_SYSTEM;
select * from PROD_DOCUMENT_DM.TN94766.DG_ATTRIBUTE;
select * from PROD_DOCUMENT_DM.TN94766.GDPR_ASSETS
where ENTITY = 'VEHICLE';

select vehicle_faultcode_id, max(LOAD_ST_DATETIME)
from STOV_LDA_VEHICLE_FAULT_CODE_ACT
group by vehicle_faultcode_id
having count(distinct VEHICLE_KEY) > 1
order by 2 desc
;



select * from STOV_LDA_VEHICLE_FAULT_CODE_ACT
where vehicle_faultcode_id = 799214824; 

select *
from PROD_VEHICLE_DM.PROD_VEHICLE_ETL.D_VEHICLE
where vehicle_key in ('RIG  #|121483', 'TT   #|35')
